import time,re,xbmcaddon
import xbmc,xbmcgui,xbmcplugin,xbmcvfs
import os,json,shutil
from resources.modules import cache
from resources.modules import log
from resources.modules.engine import download_sub,get_subtitles,sort_subtitles
from urllib.parse import  unquote_plus, unquote,  quote
from resources.modules.general import TransFolder,clean_title,CachedSubFolder,get_video_data,get_db_data,MySubFolder,notify,Thread,show_results,save_file_name
from urllib.parse import parse_qsl
from resources.modules.sub_window import MySubs
import urllib.parse
from resources.modules import general
Addon=xbmcaddon.Addon()
MyScriptName = xbmcaddon.Addon().getAddonInfo('name')
MyScriptID = xbmcaddon.Addon().getAddonInfo('id')
unque=urllib.parse.unquote_plus
monit = xbmc.Monitor()
ab_req=monit.abortRequested()
log.warning('Starting %s Service!!!'%MyScriptName)

global video_id,pre_video_id,trigger,dont_place_sub
global playing_addon,break_wait,quick_sub_value,already_placed_sub
already_placed_sub=False
quick_sub_value=""
dont_place_sub=False
break_wait=False
playing_addon=""
video_id=""
pre_video_id=""
trigger=False
que=urllib.parse.quote_plus
cache.clear(['subs'])
####################################################################################
    
# Currently only for Hebrew/English, the most common.
def translate_sub_language_to_hebrew(language):
    if "Hebrew" in language:
        return "עברית"
    elif language == "English":
        return "אנגלית"
    elif language == "Russian":
        return "רוסית"
    elif language == "Arabic":
        return "ערבית"
    else:
        return language
####################################################################################

def wait_for_video():

    log.warning('Waiting for video')
    counter=0
    vidtime_pre=0
    once=True
    
    while counter<70:
        try:
            vidtime = xbmc.Player().getTime()
            if vidtime>0:
                  if once:
                      vidtime_pre=vidtime
                      once=False
                  if vidtime_pre!=vidtime:
                      break
                  vidtime_pre=vidtime
                  if (vidtime>1):
                    break
            counter+=1
            xbmc.sleep(100)
        except:
          break
          
    log.warning(f"DEBUG | Time waited for video to start (wait_for_video): {counter/10} seconds.")

######################### EMBEDDED SUBS #####################################
    
def determine_placeHebrewEmbeddedSub(last_sub_in_cache_is_external, last_sub_in_cache_is_heb_embedded, first_external_sub_language):

    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()

    # Check if "auto_place_hebrew_embedded_subs" setting is 'true'
    if Addon.getSetting("auto_place_hebrew_embedded_subs") == 'true':
        # Check if last sub cache is not an external subtitle (not empty or not embedded Hebrew sub).
        if not last_sub_in_cache_is_external:
            return True
            
    else:
        # Check if first external subtitle language is NOT "Hebrew"
        if first_external_sub_language != "Hebrew":
            # Check if last sub cache is not an external subtitle (not empty or not embedded Hebrew sub).
            if not last_sub_in_cache_is_external:
                return True
                
        # If first_external_sub_language=="Hebrew", Check if last sub cache is Hebrew embedded
        elif last_sub_in_cache_is_heb_embedded:
            return True 
    
    return True
    
    
def wait_for_video_and_return_subs_list():

    log.warning('Waiting for video')
    counter=0
    vidtime=0
    once=True
    subs=[]
    
    while counter<70:
        try:
          
          
          vidtime = xbmc.Player().getTime()
          if vidtime>0.1:
                if once:
                    vidtime_pre=vidtime
                    once=False
                if vidtime_pre!=vidtime:
                    break
                vidtime_pre=vidtime
                if (vidtime>1):
                    break
        except:
          pass
        counter+=1
        xbmc.sleep(100)
    subs=xbmc.Player().getAvailableSubtitleStreams()
    log.warning(f'Em subs:{subs}')
    if len(subs)>0:
        log.warning(f"DEBUG | Time waited for video to start (wait_for_video_and_return_subs_list): {counter/10} seconds.")
    return subs
    
        
        
def check_if_embedded_sub_exists(embedded_language):
    subs = wait_for_video_and_return_subs_list()
    return any(sub == embedded_language for sub in subs)
    
    
def get_embedded_sub_index(subs, embedded_language):
    return next((index for index, sub in enumerate(subs) if sub == embedded_language), None)

    
def set_embedded_hebrew_sub(video_data):
    global quick_sub_value
    subs = wait_for_video_and_return_subs_list()
    index_sub = get_embedded_sub_index(subs, 'heb')
    
    if index_sub is not None:
        log.warning(f'Placing Hebrew embedded Stream Sub: index_sub={str(index_sub)}')
        xbmc.Player().setSubtitleStream(index_sub)
        quick_sub_value=index_sub
        save_data='HebrewSubEmbedded'+video_data['imdb']+str(video_data['season'])+str(video_data['episode'])+video_data['OriginalTitle']+video_data['Tagline']
        save_file_name(que(save_data),"Hebrew",video_data)
            
        xbmc.sleep(300)
        return True
    return False
    
def add_embbded_sub_if_exists(video_data, f_result, embedded_language):

    # Avoid checking when using subtitles search from context menu (display_subtitle)
    if not xbmc.Player().isPlaying():
        log.warning(f'DEBUG | add_embbded_sub_if_exists STOP | embedded_language={embedded_language} | xbmc.Player().isPlaying(): {xbmc.Player().isPlaying()}')
        return f_result

    if embedded_language=='heb':
        try:
            global is_embedded_hebrew_sub_exists
            if not is_embedded_hebrew_sub_exists:
                log.warning(f'DEBUG | add_embbded_sub_if_exists STOP | embedded_language={embedded_language} | is_embedded_hebrew_sub_exists: {is_embedded_hebrew_sub_exists}')
                return f_result
        except:
            return f_result
            pass
            
    if embedded_language=='heb':
        embedded_sub_name_prefix = 'HebrewSubEmbedded'
        FullLanguageName = 'Hebrew'
        thumbnailImageLanguageName = 'he'
        EmbeddedSubLabel = 'תרגום מובנה בעברית'
    elif embedded_language=='eng':
        embedded_sub_name_prefix = 'EnglishSubEmbedded'
        FullLanguageName = 'English'
        thumbnailImageLanguageName = 'en'
        EmbeddedSubLabel = 'תרגום מובנה באנגלית'
        
    # Exit if embedded sub is already present in f_result. Else, continue. Safe checking again.
    for items in f_result:
        if embedded_sub_name_prefix in items[8]:
            return f_result
            
    subs=wait_for_video_and_return_subs_list()
    index_sub = get_embedded_sub_index(subs, embedded_language)
    log.warning(f'add_embbded_sub_if_exists | embedded_language={embedded_language} | Embbeded subs list: {subs} | index_sub={index_sub}')

    if index_sub is not None:
        download_data={}
        download_data['url']=str(index_sub)
        download_data['file_name']=str(index_sub)
        save_data=embedded_sub_name_prefix+video_data['imdb']+str(video_data['season'])+str(video_data['episode'])+video_data['OriginalTitle']+video_data['Tagline']
  
        url = "plugin://%s/?action=download&download_data=%s&filename=%s&language=%s&source=%s" % (MyScriptID,
                                                            que(json.dumps(download_data)),
                                                            que(que(que(save_data))),
                                                            FullLanguageName,
                                                            embedded_sub_name_prefix)
        json_value={'url':url,
                             'label':FullLanguageName,
                             'label2':'[LOC] '+ EmbeddedSubLabel,
                             'iconImage':"0",
                             'thumbnailImage':thumbnailImageLanguageName,
                             'hearing_imp':'false',
                             'site_id':'[LOC]',
                             'sub_color':'cyan',
                             'filename':que(save_data),
                             'sync': 'true'}
                             
   
        index = 0
        if embedded_language=='eng':
            # Find the index where English subtitles should be inserted
            for i, sub in enumerate(f_result):
                if sub[0] == 'Hebrew':
                    index = i + 1  # Insert after the last Hebrew subtitle
                             
            
        f_result.insert(index, (json_value['label'],'[COLOR %s]'%json_value['sub_color']+json_value['label2']+'[/COLOR]',json_value['iconImage'],json_value['thumbnailImage'],json_value['url'],101,json_value['sync'],json_value['hearing_imp'],json_value['filename'],json_value['site_id']))

    return f_result
    
    
def add_embbded_subs_to_subs_list(video_data, f_result):

    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()
        
    # Add Hebrew Embbeded Subtitles if exists
    search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
    if search_language_hebrew_bool:
        f_result=add_embbded_sub_if_exists(video_data, f_result, 'heb')
        
    # Add English Embbeded Subtitles if exists
    search_language_english_bool = (Addon.getSetting('language_english') == 'true' or Addon.getSetting("all_lang") == 'true')
    if search_language_english_bool:
        f_result=add_embbded_sub_if_exists(video_data, f_result, 'eng')
    
    return f_result
        
####################################################################################
    
def isPlayingAddonExcluded(movieFullPath,playing_addon):
    excluded_addons=['idanplus','sdarot.tv','youtube','kids_new']

    playing_addon=playing_addon+movieFullPath
 
    if (playing_addon.find("pvr://") > -1) :
        log.warning("isPlayingAddonExcluded(): Video is playing via Live TV, which is currently set as excluded location.")
        return True
    if (xbmc.getInfoLabel("VideoPlayer.mpaa")=='heb'):
          log.warning("isPlayingAddonExcluded(): mpaa!!." )
          return True
    for x in excluded_addons:
        
        if x in playing_addon.lower():
            
            log.warning("isPlayingAddonExcluded(): Video is playing from '%s', which is currently set as !!excluded_addons!!."%x )
            
            return True
    if ',' in  Addon.getSetting('ExcludedAddons'):
        ExcludedAddons = Addon.getSetting('ExcludedAddons').split(',')  
    else:
        ExcludedAddons = [Addon.getSetting('ExcludedAddons')]
    for items in ExcludedAddons:
        if items.lower() in playing_addon.lower() and (len(items)>0):
            log.warning("isPlayingAddonExcluded(): Video is playing from '%s', which is currently set as !!excluded_addons!!."%items )
            return True
    return False
    
def place_sub(video_data,f_result,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,last_sub_in_cache_is_empty):
    global quick_sub_value,dont_place_sub
    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()
    
    if Addon.getSetting("enable_autosub_notifications")=='true':
        general.show_msg="מוריד כתובית נבחרת"
    # Default placing sub to the first subtitle in subtitles list results.
    selected_sub=f_result[0]
    log.warning(f"place_sub | selected_sub BEFORE checking last sub in cache: {selected_sub}")
    # Changing subtitle to place to subtitles from database.db cache db (if exists)
    if not last_sub_in_cache_is_empty:
        for f_sub in f_result:
            if (last_sub_name_in_cache==f_sub[8]) and (last_sub_language_in_cache==f_sub[0]):
                selected_sub=f_sub
                break
    log.warning(f"place_sub | selected_sub AFTER checking last sub in cache: {selected_sub}")
    
    c_sub_file=None
    place_sub_count = 0
    for f_sub in f_result:
        place_sub_count += 1
    
        params=get_params(selected_sub[4],"")
        download_data=unque(params["download_data"])
        download_data=json.loads(download_data)
        source=(params["source"])
        language=(params["language"])
        filename=unque(params["filename"])
        try:
                
            sub_file=download_sub(source,download_data,MySubFolder,language,filename)
            log.warning('Auto Sub result:'+str(sub_file))
            xbmc.sleep(200)
            wait_for_video()
            quick_sub_value=sub_file
            if not dont_place_sub:
                log.warning(f'setSubtitles:317 {sub_file}')
                xbmc.Player().setSubtitles(sub_file)        
                ################################################################################################################################
                # Reformatting variables for user notification of auto selected subtitle
                if Addon.getSetting("enable_autosub_notifications")=='true':
                    
                    from resources.modules.engine import format_website_source_name
                    notify_website_name = format_website_source_name(source)
                    notify_language = f"{translate_sub_language_to_hebrew(language)} (תרגום מכונה)" if language != "Hebrew" and Addon.getSetting("auto_translate")=='true' else translate_sub_language_to_hebrew(language)
                    notify_sync_percent = str(selected_sub[5])
                
                    notify( f"{notify_language} | {notify_sync_percent}% | {notify_website_name}" )
                ################################################################################################################################
                
                save_file_name(params["filename"],language,video_data)
                
                f_count=0
                max_sub_cache=int(Addon.getSetting("subtitle_trans_cache"))
                for filename_o in os.listdir(CachedSubFolder):
                    f_count+=1
                
                if (f_count>max_sub_cache):
                        for filename_o in os.listdir(CachedSubFolder):
                            f = os.path.join(CachedSubFolder, filename_o)
                            os.remove(f)
                try:
                    file_type=(os.path.splitext(sub_file)[1])
                except:
                    file_type=""
                c_sub_file=os.path.join(CachedSubFolder, f"{source}_{language}_{filename}{file_type}")
                if not os.path.exists(c_sub_file):
                        if file_type=='.idx'  or file_type=='.sup':
                            shutil.copy(sub_file,c_sub_file.replace('idx','sub').replace('sup','sub'))
                        try:
                            shutil.copy(sub_file,c_sub_file)
                        except Exception as e:
                            log.warning(f"shutil.copy(sub_file,c_sub_file) | Exception: {str(e)}")
                            pass
                

                
                # Break the loop since setting external subtitle was successful.
                log.warning(f"DEBUG | place_sub | Number of try: {place_sub_count} | Successfuly set external sub: {sub_file}")
                break
            else:
                break
        except Exception as e:
            # Try the next subtitle in f_result.
            log.warning(f"DEBUG | place_sub | Number of try: {place_sub_count} | Exception in Sub: {str(e)}")
            log.warning(f"DEBUG | place_sub | Number of try: {place_sub_count} | Setting selected_sub to: {f_sub}")
            selected_sub=f_sub
            continue
            
    return c_sub_file,filename
def display_subtitle(f_result,video_data,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,argv1):
    
    all_d=[]
    sub_final_data=[]
    for items in f_result:
            try:
                val = all_subs.get(items[8])
              
            except:
                val=None
                pass

            if (last_sub_name_in_cache==items[8]) and (last_sub_language_in_cache==items[0]):
                added_string='[COLOR FFFF00FE][B][I] >>> '
            elif val and items[0] in val:
                added_string='[COLOR deepskyblue][B][I]'
            else:
                added_string='[COLOR gold]'
            if xbmc.Player().isPlaying():
                sub_name=added_string+str(items[5])+ "% "+'[/COLOR]'+items[1]
                if ('[B][I]' in added_string):
                    sub_name=sub_name+'[/I][/B]'
                if video_data['file_original_path'].replace("."," ").lower() in items[1].replace("."," ").lower() and len(video_data['file_original_path'].replace("."," "))>5 or items[5]>80:
                         #json_value['label2']='[COLOR gold] GOLD [B]'+json_value['label2']+'[/B][/COLOR]'
                         sub_name='[COLOR gold] GOLD '+sub_name+'[/COLOR]'
            else:
                sub_name=items[1]
            
            sub_final_data.append({'label':items[0],
                                  'label2':sub_name, 
                                  'iconImage':items[2],
                                  'thumbnailImage':items[3],
                                  'url':items[4],
                                  
                                  "sync": items[6],
                                  "hearing_imp":items[7]})
                                       
                
    sub_final_data.append({'label':"הגדרות",
                          'label2':'[B][COLOR plum][I]'+ "DarkSubs - הגדרות"+'[/I][/COLOR][/B]', 
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=open_settings" % (MyScriptID),
                          "sync": "",
                          "hearing_imp":""})
                          
    sub_final_data.append({'label':"קאש",
                          'label2':'[B][COLOR khaki][I]'+"DarkSubs - ניקוי קאש"+'[/I][/COLOR][/B]',  
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=clean_all_cache" % (MyScriptID),
                          "sync": "",
                          "hearing_imp":""})
                          
    sub_final_data.append({'label':"חלון",
                          'label2':'[B][COLOR lightblue][I]'+ "DarkSubs - חלון כתוביות"+'[/I][/COLOR][/B]', 
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url': "plugin://%s/?action=sub_window"% (MyScriptID),
                          "sync": "",
                          "hearing_imp":""})
                          
    sub_final_data.append({'label':"ביטול",
                          'label2':'[B][COLOR seagreen][I]'+ "DarkSubs - בטל כתוביות"+'[/I][/COLOR][/B]', 
                          'iconImage':"",
                          'thumbnailImage':"",
                          'url':"plugin://%s/?action=disable_subs"% (MyScriptID),
                          "sync": "",
                          "hearing_imp":""})
    log.warning(f'DEBUG | display_subtitle | Returning {len(sub_final_data)} items')
    return sub_final_data
def get_params(argv2,argv1):
    if argv2!="None":
        param = dict(parse_qsl(argv2.replace('?','')))
    else:
        
        param={}
        param['action']=argv1
    return param
def sub_from_main(arg):
    global is_embedded_hebrew_sub_exists
    xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("main_search_subs",'')
    # For settings changes to take effect.
    Addon=xbmcaddon.Addon()
    argv2=arg.split('$$$$$$$$')[0]
    argv1=arg.split('$$$$$$$$')[1]
    params = get_params(argv2,argv1)

    video_data=get_video_data()
    action=None
    
    
    try:        
        action=(params["action"])
    except:
            pass
    log.warning(f"DEBUG | sub_from_main | action={action} | params={params}")
    try:
        download_data=unque(params["download_data"])
        download_data=json.loads(download_data)
    except:
        pass
    try:
        source=(params["source"])
    except:
        pass
    try:
        filename=unque(params["filename"])
    except:
        pass
    try:
        language=(params["language"])
    except:
        pass
    from resources.modules import general
    
    if action!="sub_window_unpause" and action!="sub_window" and Addon.getSetting("enable_autosub_notifications")=='true':
        general.show_msg="מוריד כתוביות"
        
    # Don't show dialog progress for search/download - main.py already shows it
    if action=='download':
        general.with_dp=True
    else:
        general.with_dp=False
    thread=[]
            
    thread.append(Thread(show_results))
    
    thread[0].start()
    try:
        video_data.pop('state')
        video_data.pop('media_type_videoInfoTag')
        video_data.pop('is_local_media_playing')
    except:
        pass
    log.warning(video_data)
    if action=='search':
        
     
        
        from resources import main
        main.from_autosub=True
        tag_original2=""
        tag_original3=""
        tag_original=""
        file_org=""
        search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
        is_embedded_hebrew_sub_exists = False
        if search_language_hebrew_bool:
            is_embedded_hebrew_sub_exists = check_if_embedded_sub_exists(embedded_language='heb')
        tag_original2=video_data.get('VideoPlayer.Tagline','')
        video_data.pop('VideoPlayer.Tagline',None) 
        if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
        tag_original3=video_data.get('Tagline_From_Fen')
        video_data.pop('Tagline_From_Fen',None) 
        
        tag_original=video_data.get('Tagline')
        video_data.pop('Tagline',None)
        
        file_org=video_data.get('file_original_path')
        video_data.pop('file_original_path',None)
        log.warning('Normal Search:')
        log.warning(video_data)
        
        f_result=cache.get(get_subtitles,24,video_data,table='subs')
        video_data['file_original_path']=file_org
        video_data['Tagline']=tag_original
        video_data['VideoPlayer.Tagline']=tag_original2
        video_data['Tagline_From_Fen']=tag_original3
        
        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
        # Avoid f_result=None error if no subs found.
        f_result = [] if not f_result else f_result
        
        # Add embbeded subtitles to subtitles list
        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
        ############################################################
  
        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)

        return_result=display_subtitle(f_result,video_data,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,argv1)
        log.warning(f'DEBUG | sub_from_main | action=search | f_result count: {len(f_result)}')
        log.warning(f'DEBUG | sub_from_main | action=search | return_result type: {type(return_result).__name__}')
        log.warning(f'DEBUG | sub_from_main | action=search | return_result length: {len(return_result) if isinstance(return_result, (list, dict)) else "N/A"}')
        
    
    elif action=='download':
        
        
        all_download_data=((source,download_data,MySubFolder,language,filename))
        log.warning(all_download_data)
        log.warning(params["filename"])
        sub_file=download_sub(source,download_data,MySubFolder,language,filename)
        fault=False
        if sub_file=='EmbeddedSubSelected': # embedded subtitle
            notify( 'התרגום המובנה יופיע בעוד 10 שניות' )
            log.warning(filename)
            save_file_name(filename,language,video_data)
        elif sub_file=='FaultSubException':
            notify( 'תקלה בהורדה נסה שנית' )
        else: # External subtitle
        
            log.warning('Auto Sub result:'+str(sub_file))
            xbmc.sleep(100)
            log.warning('setSubtitles:572')
            xbmc.Player().setSubtitles(sub_file)
            save_file_name(filename,language,video_data)
            f_count=0
            max_sub_cache=int(Addon.getSetting("subtitle_trans_cache"))
            for filename_o in os.listdir(CachedSubFolder):
                
                f_count+=1
            
            if (f_count>max_sub_cache):
                    for filename_o in os.listdir(CachedSubFolder):
                        f = os.path.join(CachedSubFolder, filename_o)
                        os.remove(f) 
      

            try:
                file_type=(os.path.splitext(sub_file)[1])
            except:
                file_type=""
            c_sub_file=os.path.join(CachedSubFolder, f"{source}_{language}_{filename}{file_type}")
            
            if not os.path.exists(c_sub_file):
                    if file_type=='.idx' or file_type=='.sup':
                        shutil.copy(sub_file,c_sub_file.replace('idx','sub').replace('sup','sub'))
                    
                    try:
                        shutil.copy(sub_file,c_sub_file)
                    except Exception as e:
                        log.warning(f"shutil.copy(sub_file,c_sub_file) | Exception: {str(e)}")
                        pass
                    
        return_result=json.dumps(sub_file)
        
    elif action=='open_settings':
        xbmcaddon.Addon().openSettings()
        return_result=json.dumps(action)
    elif action=='clean':
        cache.clear(['subs'])
        notify( "קאש כתוביות נוקה" )
        return_result=json.dumps(action)
    elif action=='clean_all_cache':
        xbmc.executebuiltin("RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)")
        return_result=json.dumps(action)
    elif action=='disable_subs':
        xbmc.Player().setSubtitles("")
        return_result=json.dumps(action)
        notify("כתוביות בוטלו")
    elif action=='sub_window':
        thread=[]
                    
        thread.append(Thread(run_my_window))

        thread[0].start()
        
        tag_original=video_data['Tagline']
        video_data.pop('Tagline')
        
        file_org=video_data['file_original_path']
        video_data.pop('file_original_path')
        
        tag_original2=video_data['VideoPlayer.Tagline']
        video_data.pop('VideoPlayer.Tagline') 
        
        tag_original3=video_data['Tagline_From_Fen']
        video_data.pop('Tagline_From_Fen') 
        if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
        f_result=cache.get(get_subtitles,24,video_data,table='subs')
        video_data['file_original_path']=file_org
        video_data['Tagline']=tag_original
        video_data['VideoPlayer.Tagline']=tag_original2
        video_data['Tagline_From_Fen']=tag_original3
        
        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
        # Avoid f_result=None error if no subs found.
        f_result = [] if not f_result else f_result
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.Player().pause()
        
        # Add embbeded subtitles to subtitles list
        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
        ############################################################
        
        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
        window = MySubs('DarkSubs - חלון כתוביות' ,f_result,f_result,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache)
        return_result=json.dumps(action)
    elif action=='sub_window_unpause':
        tag_original=video_data['Tagline']
        video_data.pop('Tagline')
        
        file_org=video_data['file_original_path']
        video_data.pop('file_original_path')
        
        tag_original2=video_data['VideoPlayer.Tagline']
        video_data.pop('VideoPlayer.Tagline') 
        
        tag_original3=video_data['Tagline_From_Fen']
        video_data.pop('Tagline_From_Fen') 
        if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
        f_result=cache.get(get_subtitles,24,video_data,table='subs')
        video_data['file_original_path']=file_org
        video_data['Tagline']=tag_original
        video_data['VideoPlayer.Tagline']=tag_original2
        video_data['Tagline_From_Fen']=tag_original3
        
        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
        # Avoid f_result=None error if no subs found.
        f_result = [] if not f_result else f_result
        xbmc.executebuiltin('Dialog.Close(all,true)')
        
        # Add embbeded subtitles to subtitles list
        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
        ############################################################
        
        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
        window = MySubs('DarkSubs - חלון כתוביות' ,f_result,f_result,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache)
        return_result=json.dumps(action)
    elif action=='next':
        from resources.modules import general
        general.with_dp=False
        general.show_msg="כתובית הבאה"
        log.warning(general.show_msg)
        thread=[]
                    
        thread.append(Thread(show_results))

        thread[0].start()
    
        tag_original=video_data['Tagline']
        video_data.pop('Tagline')
        
        file_org=video_data['file_original_path']
        video_data.pop('file_original_path')
        
        tag_original2=video_data['VideoPlayer.Tagline']
        video_data.pop('VideoPlayer.Tagline') 
        
        tag_original3=video_data['Tagline_From_Fen']
        video_data.pop('Tagline_From_Fen') 
        if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
        f_result=cache.get(get_subtitles,24,video_data,table='subs')
        video_data['file_original_path']=file_org
        video_data['Tagline']=tag_original
        video_data['VideoPlayer.Tagline']=tag_original2
        video_data['Tagline_From_Fen']=tag_original3
        
        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
        # Avoid f_result=None error if no subs found.
        f_result = [] if not f_result else f_result
        
        # Add embbeded subtitles to subtitles list
        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
        ############################################################
        
        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
        next_one=False
        selected_sub=None
        for items in f_result:
            if (next_one):
                if (last_sub_name_in_cache!=items[8]) and (last_sub_language_in_cache!=items[0]):
                    selected_sub=items
                    
                    break
                else:
                    next_one=False
            if (last_sub_name_in_cache==items[8]) and (last_sub_language_in_cache==items[0]):
                next_one=True
            
        if selected_sub:
            params=get_params(selected_sub[4],"")
            download_data=unque(params["download_data"])
            download_data=json.loads(download_data)
            source=(params["source"])
            language=(params["language"])
            filename=params["filename"]
            general.show_msg="מוריד"
            sub_file=download_sub(source,download_data,MySubFolder,language,filename)
            log.warning('Next Sub result:'+str(sub_file))
            general.show_msg="מוכן"
            if (sub_file!='EmbeddedSubSelected') and (sub_file!='FaultSubException'):
                log.warning('setSubtitles:755')
                xbmc.Player().setSubtitles(sub_file)
            save_file_name(filename,language,video_data)
            
        else:
            general.show_msg="סוף הכתוביות"
            
        xbmc.sleep(800)
        general.show_msg="END"
        return_result=json.dumps(action)
    elif action=='previous':
        from resources.modules import general
        general.with_dp=False
        general.show_msg="כתובית קודמת"
        
        thread=[]
                    
        thread.append(Thread(show_results))

        thread[0].start()
        tag_original=video_data['Tagline']
        video_data.pop('Tagline')
        
        file_org=video_data['file_original_path']
        video_data.pop('file_original_path')
        
        tag_original2=video_data['VideoPlayer.Tagline']
        video_data.pop('VideoPlayer.Tagline') 
        
        tag_original3=video_data['Tagline_From_Fen']
        video_data.pop('Tagline_From_Fen') 
        if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
        f_result=cache.get(get_subtitles,24,video_data,table='subs')
        video_data['file_original_path']=file_org
        video_data['Tagline']=tag_original
        video_data['VideoPlayer.Tagline']=tag_original2
        video_data['Tagline_From_Fen']=tag_original3
        
        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
        # Avoid f_result=None error if no subs found.
        f_result = [] if not f_result else f_result
        
        # Add embbeded subtitles to subtitles list
        f_result = add_embbded_subs_to_subs_list(video_data, f_result)
        ############################################################
        
        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
        pre_one=None
        found=None
        for items in f_result:
            if (found):
                if ((pre_one) and (last_sub_name_in_cache!=pre_one[8]) and (last_sub_language_in_cache!=pre_one[0])):
                    selected_sub=pre_one
                    
                    break
                else:
                    found=None
            if (last_sub_name_in_cache==items[8]) and (last_sub_language_in_cache==items[0]):
                found=True
            else:
                pre_one=items
        log.warning('found_P:'+str(found))
        if found:
            params=get_params(selected_sub[4],"")
            download_data=unque(params["download_data"])
            download_data=json.loads(download_data)
            source=(params["source"])
            language=(params["language"])
            filename=params["filename"]
            sub_file=download_sub(source,download_data,MySubFolder,language,filename)
            
            log.warning('previous Sub result:'+str(sub_file))
            general.show_msg=sub_file
            xbmc.sleep(100)
            if (sub_file!='EmbeddedSubSelected') and (sub_file!='FaultSubException'):
                log.warning('setSubtitles:832')
                xbmc.Player().setSubtitles(sub_file)
                save_file_name(filename,language,video_data)
            else:
                save_file_name(unque(filename),language,video_data)
                
        else:
            general.show_msg="זאת הכתובית הראשונה"
            xbmc.sleep(800)
        general.show_msg="END"
        return_result=json.dumps(action)
    elif action=='clean_folders':
        general.show_msg="מוחק קבצים"
        try:
            shutil.rmtree(CachedSubFolder)
        except: pass
        xbmcvfs.mkdirs(CachedSubFolder)
        try:
            shutil.rmtree(TransFolder)
        except: pass
        xbmcvfs.mkdirs(TransFolder)
        return_result=json.dumps(action)
        general.show_msg="END"
        xbmc.sleep(300)

        if not os.path.exists(CachedSubFolder):
             os.makedirs(CachedSubFolder)


        if not os.path.exists(TransFolder):
             os.makedirs(TransFolder)
             
        notify( "קאש תרגום מכונה נוקה" )

    log.warning(f'DEBUG | sub_from_main | Setting main_search_return | return_result defined: {"return_result" in locals()}')
    if 'return_result' in locals():
        log.warning(f'DEBUG | sub_from_main | return_result type: {type(return_result).__name__} | length: {len(return_result) if isinstance(return_result, (list, dict)) else len(str(return_result))}')
        json_str = json.dumps(return_result)
        log.warning(f'DEBUG | sub_from_main | JSON string length: {len(json_str)}')
        xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("main_search_return", json_str)
        log.warning('DEBUG | sub_from_main | setSetting completed successfully')
    else:
        log.warning('ERROR | sub_from_main | return_result NOT DEFINED - this is the bug!')
        xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("main_search_return", json.dumps([]))
    general.show_msg="END"


def is_hebrew(term):
    """
    Check if a character or string contains Hebrew characters.
    BUGFIX: Handle both str and unicode properly for Python 2/3 compatibility.
    """
    try:
        if not term:
            return False
        
        # Ensure we're working with a string
        if not isinstance(term, str):
            try:
                term = str(term)
            except:
                return False
        
        import unicodedata
        hebrew = False
        
        for i in term:
            try:
                # Skip empty characters
                if not i or not i.strip():
                    continue
                    
                if 'HEBREW' in unicodedata.name(i.strip()):
                    hebrew = True
                    break
            except (ValueError, TypeError):
                # Character doesn't have a unicode name, skip it
                continue
        
        return hebrew
        
    except Exception as e:
        log.warning(f'Error in is_hebrew:{e}')
        return False


def play_auto_sub():
        global video_id,pre_video_id,trigger,dont_place_sub
        global playing_addon,break_wait,quick_sub_value,already_placed_sub
        try:
            
            Addon=xbmcaddon.Addon()
            from resources.modules import general
            last_sub_name_in_cache=""
            is_playing_addon_excluded=False
            manual_search=""
            while  manual_search!='':
                manual_search=xbmcaddon.Addon('service.subtitles.All_Subs').getSetting("fast_subs")
                xbmc.sleep(100)
            
            video_data=get_video_data()
            pre_video_id=video_id
      
            video_id=video_data['OriginalTitle']+video_data['imdb']+str(video_data['season'])+str(video_data['episode'])
            
            if (video_id!=pre_video_id):
                
                
                trigger=True
            # Always trigger autosub, even when replaying the same content    
            
            # pre_video_id=video_id
            

            sub_name=None
            global is_embedded_hebrew_sub_exists
            is_embedded_hebrew_sub_exists=False
            wait_for_video()
        
            if  trigger:
                trigger=False
                f_result=None
                if 'OriginalTitle' in video_data:
                    test_name=video_data['OriginalTitle']
                else:
                    test_name=video_data['title']
                check_auto=is_hebrew(test_name)
                log.warning('check_auto::'+str(check_auto))
                log.warning(test_name)
                if not check_auto:
                    try:
                        a=int(quick_sub_value)
                        log.warning('setSubtitles:927')
                        xbmc.Player().setSubtitleStream(a)
                    except:
                        log.warning('setSubtitles:930')
                        xbmc.Player().setSubtitles(quick_sub_value) 
                
                quick_sub_value=""
                force_download=True
                if  Addon.getSetting("force")=='true':
                  force_download=True
                if  Addon.getSetting("force")=='false' and xbmc.getCondVisibility("VideoPlayer.HasSubtitles"):
                  force_download=False
                
                
                log.warning('playing_addon::'+str(playing_addon))
                
                if Addon.getSetting("autosub")=='true':
                  try:
                      movieFullPath = xbmc.Player().getPlayingFile()

                      is_playing_addon_excluded=isPlayingAddonExcluded(movieFullPath,playing_addon)
                  except: pass
                  if is_playing_addon_excluded:
                    trigger=False
                  
                  if is_playing_addon_excluded and not check_auto:
                        # Set is_embedded_hebrew_sub_exists to True if embedded Hebrew subs exists in playing video.
                        search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
                        is_embedded_hebrew_sub_exists = False
                        if search_language_hebrew_bool:
                            is_embedded_hebrew_sub_exists = check_if_embedded_sub_exists(embedded_language='heb')
                            log.warning(f'is_embedded_hebrew_sub_exists:{is_embedded_hebrew_sub_exists}')
                        placeHebrewEmbeddedSub = False
                        if search_language_hebrew_bool and is_embedded_hebrew_sub_exists:
                            first_external_sub_language = ''
                            last_sub_in_cache_is_empty = True if last_sub_name_in_cache=='' else False
                            last_sub_in_cache_is_heb_embedded = True if 'HebrewSubEmbedded' in last_sub_name_in_cache else False
                            last_sub_in_cache_is_external = not last_sub_in_cache_is_empty and not last_sub_in_cache_is_heb_embedded
                            placeHebrewEmbeddedSub = determine_placeHebrewEmbeddedSub(last_sub_in_cache_is_external, last_sub_in_cache_is_heb_embedded, first_external_sub_language)
                                    
                        log.warning(f"DEBUG | placeHebrewEmbeddedSub: {placeHebrewEmbeddedSub}")   
                  
                        # If placeHebrewEmbeddedSub=True - Place the embedded Hebrew subtitles.
                        if placeHebrewEmbeddedSub:
                            # I don't know why but only by wait_for_video() before + after the hebrew subs set, the general.show_msg appears. (anyway its waiting 0 seconds, since video already started)
                            xbmc.executebuiltin('Dialog.Close(all,true)')
                            wait_for_video()
                            log.warning('DEBUG | Placing embedded Hebrew sub.')
                            result=set_embedded_hebrew_sub(video_data)
                            if result:
                                dont_place_sub=True
                                if Addon.getSetting("enable_autosub_notifications")=='true':
                                
                                    wait_for_video()
                                    
                                    notify( "עברית | 101% | תרגום מובנה" )
                                    if (already_placed_sub==False):
                                        general.show_msg="[COLOR lightblue]התרגום המובנה בעברית יופיע בעוד 10 שניות[/COLOR]" if last_sub_in_cache_is_empty else "[COLOR lightblue]התרגום המובנה בעברית יופיע בעוד 10 שניות\n(הכתובית נבחרה מהקאש)[/COLOR]"
                                    # Show the message for 5 seconds before general.show_msg="END"
                                    xbmc.sleep(5000)
                  if force_download==True and not is_playing_addon_excluded:
                  
                    
                    if  Addon.getSetting("pause")=='true':
                        xbmc.Player().pause()
                    
                    if Addon.getSetting("enable_autosub_notifications")=='true':
                        if (already_placed_sub==False):
                            general.show_msg="מוריד כתוביות"
                    general.with_dp=False
                    thread=[]
                            
                    thread.append(Thread(show_results))
                    from resources import main
                    main.from_autosub=True
                    thread[0].start()
                    
                    video_data.pop('state') 
                    video_data.pop('is_local_media_playing')
                    try:
                        tag_original2=video_data.get('VideoPlayer.Tagline','')
                        video_data.pop('VideoPlayer.Tagline',None) 
                        
                        tag_original3=video_data.get('Tagline_From_Fen')
                        video_data.pop('Tagline_From_Fen',None) 
                        
                        tag_original=video_data.get('Tagline')
                        video_data.pop('Tagline',None)
                        
                        file_org=video_data.get('file_original_path')
                        video_data.pop('file_original_path',None)
                        if 'year' in video_data:
                            if video_data['year'] == '':
                                video_data['year'] = '0'
                        log.warning('Auto Search:')
                        log.warning(video_data)
                        f_result=cache.get(get_subtitles,24,video_data,table='subs')
                        video_data['file_original_path']=file_org
                        video_data['Tagline']=tag_original
                        video_data['VideoPlayer.Tagline']=tag_original2
                        video_data['Tagline_From_Fen']=tag_original3
                        
                        f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
                        # Avoid f_result=None error if no subs found.
                        f_result = [] if not f_result else f_result
                        
                        # Set is_embedded_hebrew_sub_exists to True if embedded Hebrew subs exists in playing video.
                        search_language_hebrew_bool = (Addon.getSetting('language_hebrew') == 'true' or Addon.getSetting("all_lang") == 'true')
                        is_embedded_hebrew_sub_exists = False
                        if search_language_hebrew_bool:
                            is_embedded_hebrew_sub_exists = check_if_embedded_sub_exists(embedded_language='heb')
                        
                        # Gets last chosen subtitle from subtitles cache DB (if exists) for playing video tagline.
                        last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
                        
                        # Get sub language of first subtitle in external subs list found.
                        if len(f_result) > 0:
                            first_external_sub_params = get_params(f_result[0][4], "")
                            first_external_sub_language = first_external_sub_params.get("language")
                        else:
                            first_external_sub_language = ''
                        
                        last_sub_in_cache_is_empty = True if last_sub_name_in_cache=='' else False
                        last_sub_in_cache_is_heb_embedded = True if 'HebrewSubEmbedded' in last_sub_name_in_cache else False
                        last_sub_in_cache_is_external = not last_sub_in_cache_is_empty and not last_sub_in_cache_is_heb_embedded
                        
                        # LOGGING
                        log.warning(f"DEBUG | first_external_sub_language: {first_external_sub_language}")
                        log.warning(f"DEBUG | search_language_hebrew_bool: {search_language_hebrew_bool}")
                        log.warning(f"DEBUG | is_embedded_hebrew_sub_exists: {is_embedded_hebrew_sub_exists}")
                        log.warning(f"DEBUG | auto_place_hebrew_embedded_subs setting: {Addon.getSetting('auto_place_hebrew_embedded_subs')}")
                        log.warning(f"DEBUG | last_sub_name_in_cache: {last_sub_name_in_cache}")
                        log.warning(f"DEBUG | last_sub_language_in_cache: {last_sub_language_in_cache}")
                        log.warning(f"DEBUG | last_sub_in_cache_is_empty: {last_sub_in_cache_is_empty}")
                        log.warning(f"DEBUG | last_sub_in_cache_is_heb_embedded: {last_sub_in_cache_is_heb_embedded}")
                        log.warning(f"DEBUG | last_sub_in_cache_is_external: {last_sub_in_cache_is_external}")

                        # set placeHebrewEmbeddedSub value
                        placeHebrewEmbeddedSub = False
                        if search_language_hebrew_bool and is_embedded_hebrew_sub_exists:
                            placeHebrewEmbeddedSub = determine_placeHebrewEmbeddedSub(last_sub_in_cache_is_external, last_sub_in_cache_is_heb_embedded, first_external_sub_language)
                                    
                        log.warning(f"DEBUG | placeHebrewEmbeddedSub: {placeHebrewEmbeddedSub}")   
                  
                        # If placeHebrewEmbeddedSub=True - Place the embedded Hebrew subtitles.
                        if placeHebrewEmbeddedSub:
                            # I don't know why but only by wait_for_video() before + after the hebrew subs set, the general.show_msg appears. (anyway its waiting 0 seconds, since video already started)
                            wait_for_video()
                            log.warning('DEBUG | Placing embedded Hebrew sub.')
                            set_embedded_hebrew_sub(video_data)
            
                            if Addon.getSetting("enable_autosub_notifications")=='true':
                            
                                wait_for_video()
                                
                                notify( "עברית | 101% | תרגום מובנה" )
                                if (already_placed_sub==False):
                
                                    general.show_msg="[COLOR lightblue]התרגום המובנה בעברית יופיע בעוד 10 שניות[/COLOR]" if last_sub_in_cache_is_empty else "[COLOR lightblue]התרגום המובנה בעברית יופיע בעוד 10 שניות\n(הכתובית נבחרה מהקאש)[/COLOR]"
                                # Show the message for 5 seconds before general.show_msg="END"
                                xbmc.sleep(5000)
                        
                        # If placeHebrewEmbeddedSub=False and f_result list is not empty - place sub from external subtitles list.
                        else:
                            wait_for_video()
                            
                            if len(f_result)>0:
                                sub_name,sub_filename=place_sub(video_data,f_result,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,last_sub_in_cache_is_empty)
                            
                            if Addon.getSetting("enable_autosub_notifications")=='true':
                                if (already_placed_sub==False):
                                    if sub_name:
                                        general.show_msg=f"[COLOR lightblue]כתובית מוכנה\n{sub_filename}[/COLOR]" if last_sub_in_cache_is_empty else f"[COLOR lightblue]כתובית מוכנה\n{sub_filename}\n(הכתובית נבחרה מהקאש)[/COLOR]"
                                        
                                    else:
                                        general.show_msg="[COLOR red]אין כתוביות[/COLOR]"
                                    
                                # Show the message for 5 seconds before general.show_msg="END"
                                #xbmc.sleep(5000)
                                
                                if search_language_hebrew_bool and is_embedded_hebrew_sub_exists:
                                    notify( "קיים גם תרגום מובנה בעברית" )
      
                    except Exception as e:
                        import linecache
              
                        exc_type, exc_obj, tb = sys.exc_info()
                        f = tb.tb_frame
                        lineno = tb.tb_lineno
                        filename = f.f_code.co_filename
                        linecache.checkcache(filename)
                        log.warning('Error in subs:'+str(e)+','+'line:'+str(lineno))
                        
                        
                  else:
                    log.warning('Not Downloading:')
                    log.warning(f"force_download={force_download}")
                    log.warning(f"is_playing_addon_excluded={is_playing_addon_excluded}")
        finally:
            general.show_msg="END"
                    
xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("main_search_subs",'')
xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("fast_subs",'')
xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("quick_subs",'')
def sub_from_mando(Mando_search):
    from resources import main
    xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("fast_subs",'')
            
    video_data=unque(Mando_search)
    
    video_data=json.loads(video_data)
    
    if 'imdb' not in video_data:
        video_data=get_video_data()
    if 'TVShowTitle' not in video_data:
        video_data['TVShowTitle']=""
    if 'mpaa' not in video_data:
        video_data['mpaa']=""
    if 'year' in video_data:
        if video_data['year'] == '':
            video_data['year'] = '0'
    video_data['title']=clean_title(video_data['title'])
    video_data['OriginalTitle']=clean_title(video_data['OriginalTitle'])
    video_data['TVShowTitle']=clean_title(video_data['TVShowTitle'])
    from resources import main
    main.from_autosub=True
    tag_original=video_data['Tagline']
    video_data.pop('Tagline')
    
    log.warning('Mando_search:')
    log.warning(video_data)


    
    f_result=cache.get(get_subtitles,24,video_data,table='subs')
    
    video_data['Tagline']=tag_original
    video_data['Tagline']=tag_original
            
    xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("fast_search_return",json.dumps(f_result))
def sub_from_mando_quick(Mando_quick_subs):
            global already_placed_sub
            xbmcaddon.Addon('service.subtitles.All_Subs').setSetting("quick_subs","")
            video_data=unque(Mando_quick_subs)
            
            video_data=json.loads(video_data)
            
            
        
            log.warning(video_data)
            if 'imdb' not in video_data:
                video_data=get_video_data()
            if 'TVShowTitle' not in video_data:
                video_data['TVShowTitle']=""
            
            if 'year' in video_data:
                if video_data['year'] == '':
                    video_data['year'] = '0'
            video_data['title']=clean_title(video_data['title'])
            video_data['OriginalTitle']=clean_title(video_data['OriginalTitle'])
            video_data['TVShowTitle']=clean_title(video_data['TVShowTitle'])
            from resources import main
            main.from_autosub=True
            tag_original=video_data['Tagline']
            video_data.pop('Tagline')
            log.warning('FoundMando_search33:')
            log.warning(video_data)
            f_result=cache.get(get_subtitles,24,video_data,table='subs')
            
            #video_data=get_video_data()
            
            video_data['Tagline']=tag_original
            video_data['Tagline']=tag_original
            video_data['VideoPlayer.Tagline']=tag_original
            video_data['Tagline_From_Fen']=tag_original
            video_data['file_original_path']=tag_original
            log.warning("Mando_quick_subs_sort::")
            log.warning(video_data)
            
            f_result=cache.get(sort_subtitles,24,f_result,video_data,table='subs')
            f_result = [] if not f_result else f_result
            log.warning("Mando_quick_subs_sort1::")

            log.warning("Mando_quick_subs_sort2::")
            # Gets last chosen subtitle from subtitles cache DB (if exists) for playing video tagline.
            last_sub_name_in_cache,last_sub_language_in_cache,all_subs=get_db_data(video_data)
            
            # Get sub language of first subtitle in external subs list found.
            if len(f_result) > 0:
                first_external_sub_params = get_params(f_result[0][4], "")
                first_external_sub_language = first_external_sub_params.get("language")
            else:
                first_external_sub_language = ''
            
            last_sub_in_cache_is_empty = True if last_sub_name_in_cache=='' else False
            last_sub_in_cache_is_heb_embedded = True if 'HebrewSubEmbedded' in last_sub_name_in_cache else False
            last_sub_in_cache_is_external = not last_sub_in_cache_is_empty and not last_sub_in_cache_is_heb_embedded
            
            # LOGGING
            log.warning(f"DEBUG | first_external_sub_language: {first_external_sub_language}")
            
 
            log.warning(f"DEBUG | auto_place_hebrew_embedded_subs setting: {Addon.getSetting('auto_place_hebrew_embedded_subs')}")
            log.warning(f"DEBUG | last_sub_name_in_cache: {last_sub_name_in_cache}")
            log.warning(f"DEBUG | last_sub_language_in_cache: {last_sub_language_in_cache}")
            log.warning(f"DEBUG | last_sub_in_cache_is_empty: {last_sub_in_cache_is_empty}")
            log.warning(f"DEBUG | last_sub_in_cache_is_heb_embedded: {last_sub_in_cache_is_heb_embedded}")
            log.warning(f"DEBUG | last_sub_in_cache_is_external: {last_sub_in_cache_is_external}")

            
                
            sub_name=None
            if len(f_result)>0:
                sub_name,sub_filename=place_sub(video_data,f_result,last_sub_name_in_cache,last_sub_language_in_cache,all_subs,last_sub_in_cache_is_empty)
                already_placed_sub=True
            if Addon.getSetting("enable_autosub_notifications")=='true':
            
                if sub_name:
                    general.show_msg=f"[COLOR lightblue]כתובית מוכנה\n{sub_filename}[/COLOR]" if last_sub_in_cache_is_empty else f"[COLOR lightblue]כתובית מוכנה\n{sub_filename}\n(הכתובית נבחרה מהקאש)[/COLOR]"
                    
                else:
                    general.show_msg="[COLOR red]אין כתוביות[/COLOR]"
                    
                # Show the message for 5 seconds before general.show_msg="END"
                #xbmc.sleep(5000)
class KodiMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        global trigger
        Addon=xbmcaddon.Addon()
        #notify('Settings change')
        manual_search=xbmcaddon.Addon('service.subtitles.All_Subs').getSetting("main_search_subs")
        if  manual_search!='':

            # Reset main_search_subs setting (bug fix --> search/download actions ran "sub_from_main" twice)
            
            thread=[]
                            
            thread.append(Thread(sub_from_main,manual_search))
            
            thread[0].start()
            #sub_from_main(manual_search)
        
            general.show_msg="END"

        Mando_search=xbmcaddon.Addon('service.subtitles.All_Subs').getSetting("fast_subs")
        if Mando_search!='':
            
            thread=[]
                            
            thread.append(Thread(sub_from_mando,Mando_search))
            
            thread[0].start()

        Mando_quick_subs=xbmcaddon.Addon('service.subtitles.All_Subs').getSetting("quick_subs")
        if Mando_quick_subs!='':
            thread=[]
                            
            thread.append(Thread(sub_from_mando_quick,Mando_quick_subs))
            
            thread[0].start()
            

                
                
      
            
    def onNotification( self, sender, method, data):
        global video_id,pre_video_id,trigger,dont_place_sub
        global playing_addon,break_wait,quick_sub_value
        # For settings changes to take effect.
        
        if method=='Player.OnStop':
            trigger=False
            dont_place_sub=False
            video_id=""
            xbmcgui.Window(10000).setProperty("subs.player_filename","")
            break_wait=True
            
        if method=='Player.OnPlay':
            log.warning('Player ONONON::')
            thread=[]
            
            thread.append(Thread(play_auto_sub))
            
            thread[0].start()
    
            
            general.show_msg="END"
monitor=KodiMonitor()

###################################################################################################################################################
# Auto clean DarkSubs cache + machine translate folders on Kodi startup.
if  Addon.getSetting("clean_cache_on_startup") == 'true':
    try:
        log.warning("Clean cache on startup Starting...")
        xbmc.executebuiltin("RunScript(special://home/addons/service.subtitles.All_Subs/resources/modules/clean_cache_functions.py, clean_all_cache)")
        log.warning("Clean cache on startup Finished.")
    except Exception as e:
        log.warning(f"Clean cache on startup FAILED. ERROR: {str(e)}")
        pass
###################################################################################################################################################

while not ab_req:
    playing_addon = general.get_playing_addon(playing_addon)
    if monitor.waitForAbort(1):
       break
del monitor