# -*- coding: utf-8 -*-
import sys, xbmcgui, xbmc, xbmcplugin, xbmcaddon
import json
from resources.modules import log
from resources.modules.general import show_results, Thread


def start():
    """
    Main entry point for All_Subs subtitle search.
    Optimized for faster load time and immediate user feedback.
    """
    log.warning('Starting Allsubs')
    
    # Cache addon instance to avoid repeated initialization (5-10ms per call)
    try:
        addon = xbmcaddon.Addon('service.subtitles.All_Subs')
        log.warning('DEBUG | main.py | Addon instance created successfully')
    except Exception as e:
        log.warning(f'ERROR | main.py | Failed to create addon instance: {e}')
        return
    
    all_d = []
    handle = None
    
    log.warning(f'DEBUG | main.py | sys.argv length: {len(sys.argv)}')
    if len(sys.argv) >= 2:
        # Check if this is a download action - if so, don't show progress dialog (autosub.py handles it)
        is_download_action = len(sys.argv) >= 3 and 'action=download' in sys.argv[2]
        
        # Show progress dialog only for search actions
        progress = None
        if not is_download_action:
            log.warning('DEBUG | main.py | About to create progress dialog')
            progress = xbmcgui.DialogProgress()
            log.warning('DEBUG | main.py | Progress dialog object created')
            progress.create('DarkSubs', 'מחפש כתוביות...')
            log.warning('DEBUG | main.py | Progress dialog shown to user')
        
        try:
            # Clear previous results
            addon.setSetting("main_search_return", "")
            log.warning(sys.argv)
            
            # Build search data
            try:
                sub_data = sys.argv[2] + '$$$$$$$$' + sys.argv[1]
            except:
                sub_data = "None" + '$$$$$$$$' + sys.argv[1]
            
            # Trigger search
            addon.setSetting("main_search_subs", sub_data)
            
            # Optimized polling with progress feedback
            response = ""
            timeout = 0
            max_timeout = 400  # 40 seconds
            
            # For download actions (no progress dialog), wait briefly; for search, poll with progress
            while response == "" and (not progress or not progress.iscanceled()):
                # CRITICAL: Create fresh addon instance each poll to bypass thread cache
                fresh_addon = xbmcaddon.Addon('service.subtitles.All_Subs')
                response = fresh_addon.getSetting("main_search_return")
                
                # Update progress every 10 iterations (1 second) - only if we have a progress dialog
                if progress and timeout % 10 == 0:
                    percent = min(int((timeout / max_timeout) * 100), 99)
                    # Kodi 21 DialogProgress.update() takes only 2 args: percent and message
                    progress.update(percent, f'מחפש כתוביות... {timeout//10}s')
                
                xbmc.sleep(100)
                timeout += 1
                
                if timeout > max_timeout:
                    log.warning('Search timeout after 40 seconds')
                    break
            
            if progress:
                progress.close()
            
            if progress and progress.iscanceled():
                log.warning('Search cancelled by user')
                return
            
            log.warning(f'DEBUG | main.py | Response received | Type: {type(response).__name__} | Length: {len(response) if response else 0}')
            log.warning(f'DEBUG | main.py | Response content (first 200 chars): {response[:200] if response else "EMPTY"}')
            
            # Parse response if available
            if response:
                try:
                    response = json.loads(response)
                    
                    # Check if response contains subtitle data
                    if isinstance(response, list) and len(response) > 0:
                        # Check if first item has required fields
                        first_item = response[0] if response else {}
                        if isinstance(first_item, dict) and 'hearing_imp' in first_item and 'thumbnailImage' in first_item:
                            # Build directory items
                            for items in response:
                                listitem = xbmcgui.ListItem(
                                    label=items['label'],
                                    label2=items['label2']
                                )
                                listitem.setArt({
                                    'thumb': items['thumbnailImage'],
                                    'icon': items['iconImage']
                                })
                                listitem.setProperty("sync", items["sync"])
                                listitem.setProperty("hearing_imp", items["hearing_imp"])
                                
                                all_d.append((items['url'], listitem, False))
                        else:
                            # Handle non-subtitle responses (commands)
                            response_str = str(response).replace('\\\\', '\\')
                            log.warning(f'Non-subtitle response: {response_str}')
                            
                            if response_str not in ['"clean"', '"open_settings"']:
                                xbmc.executebuiltin('Dialog.Close(all,true)')
                    else:
                        # Handle string response
                        response_str = str(response).replace('\\\\', '\\')
                        log.warning(f'String response: {response_str}')
                        
                        if response_str not in ['"clean"', '"open_settings"']:
                            xbmc.executebuiltin('Dialog.Close(all,true)')
                            
                except (json.JSONDecodeError, ValueError) as e:
                    log.warning(f'JSON parse error: {e}')
            else:
                log.warning('Empty response from search')
        
        except Exception as e:
            log.warning(f'Error in search process: {e}')
            if 'progress' in locals() and progress:
                progress.close()
    
    # Validate handle
    try:
        handle = int(sys.argv[1])
    except (ValueError, IndexError):
        log.warning('Exiting Allsubs - invalid handle')
        return
    
    # Add directory items to Kodi
    try:
        log.warning(f'DEBUG | main.py | About to display | all_d count: {len(all_d)} | handle: {handle}')
        if all_d:
            xbmcplugin.addDirectoryItems(handle, all_d, len(all_d))
            xbmc.sleep(100)
            xbmcplugin.endOfDirectory(handle, updateListing=True, cacheToDisc=True)
            log.warning(f'Subtitles list displayed successfully - {len(all_d)} items')
        else:
            log.warning('No subtitle items to display - all_d is empty')
            xbmcplugin.endOfDirectory(handle, succeeded=False)
    except Exception as e:
        log.warning(f'Error adding directory items: {e}')
