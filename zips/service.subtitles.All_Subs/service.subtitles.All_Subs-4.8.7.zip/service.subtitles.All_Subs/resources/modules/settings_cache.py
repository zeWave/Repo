# -*- coding: utf-8 -*-
"""
Settings Cache Module for All_Subs
Reduces disk I/O by caching addon settings with TTL (Time To Live)
"""

import time
import xbmcaddon
from resources.modules import log

class SettingsCache:
    """
    Thread-safe settings cache with TTL to reduce repeated Addon.getSetting() calls.
    Each getSetting() reads from disk (~5-10ms), so caching provides significant speedup.
    """
    
    def __init__(self, ttl=300):  # 5 minute default TTL
        """
        Initialize settings cache.
        
        Args:
            ttl (int): Time to live in seconds (default 300 = 5 minutes)
        """
        self._cache = {}
        self._timestamps = {}
        self._ttl = ttl
        self._addon = None
        
    def _get_addon(self):
        """Lazy load addon instance to avoid initialization issues."""
        if self._addon is None:
            try:
                self._addon = xbmcaddon.Addon('service.subtitles.All_Subs')
            except:
                self._addon = xbmcaddon.Addon()
        return self._addon
    
    def get(self, key, default=''):
        """
        Get setting value with caching.
        
        Args:
            key (str): Setting key name
            default (str): Default value if setting not found
            
        Returns:
            str: Setting value
        """
        current_time = time.time()
        
        # Check if cached and not expired
        if key in self._cache and key in self._timestamps:
            if (current_time - self._timestamps[key]) < self._ttl:
                return self._cache[key]
        
        # Cache miss or expired - fetch from addon
        try:
            value = self._get_addon().getSetting(key)
            self._cache[key] = value
            self._timestamps[key] = current_time
            return value
        except Exception as e:
            log.error(f'SettingsCache error for key "{key}": {e}')
            return default
    
    def get_bool(self, key, default=False):
        """
        Get boolean setting value.
        
        Args:
            key (str): Setting key name
            default (bool): Default value if setting not found
            
        Returns:
            bool: True if setting is 'true', else False
        """
        value = self.get(key, 'false' if not default else 'true')
        return value.lower() == 'true'
    
    def get_int(self, key, default=0):
        """
        Get integer setting value.
        
        Args:
            key (str): Setting key name
            default (int): Default value if setting not found
            
        Returns:
            int: Integer value of setting
        """
        try:
            return int(self.get(key, str(default)))
        except ValueError:
            return default
    
    def invalidate(self, key=None):
        """
        Invalidate cache entry or entire cache.
        
        Args:
            key (str, optional): Specific key to invalidate, or None for all
        """
        if key is None:
            self._cache.clear()
            self._timestamps.clear()
            log.warning('SettingsCache: All entries invalidated')
        elif key in self._cache:
            del self._cache[key]
            del self._timestamps[key]
            log.warning(f'SettingsCache: Invalidated key "{key}"')
    
    def set_ttl(self, ttl):
        """
        Update TTL for cache entries.
        
        Args:
            ttl (int): New TTL in seconds
        """
        self._ttl = ttl
        log.warning(f'SettingsCache: TTL set to {ttl} seconds')
    
    def get_stats(self):
        """
        Get cache statistics.
        
        Returns:
            dict: Cache stats (size, oldest entry age)
        """
        if not self._timestamps:
            return {'size': 0, 'oldest_age': 0}
        
        current_time = time.time()
        oldest_age = max(current_time - ts for ts in self._timestamps.values())
        
        return {
            'size': len(self._cache),
            'oldest_age': oldest_age
        }


# Global instance for addon-wide use
_settings_cache = SettingsCache(ttl=300)  # 5 minute TTL


def get_setting(key, default=''):
    """
    Module-level function for easy access.
    
    Args:
        key (str): Setting key name
        default (str): Default value
        
    Returns:
        str: Setting value
    """
    return _settings_cache.get(key, default)


def get_setting_bool(key, default=False):
    """
    Module-level function for boolean settings.
    
    Args:
        key (str): Setting key name
        default (bool): Default value
        
    Returns:
        bool: Setting value as boolean
    """
    return _settings_cache.get_bool(key, default)


def get_setting_int(key, default=0):
    """
    Module-level function for integer settings.
    
    Args:
        key (str): Setting key name
        default (int): Default value
        
    Returns:
        int: Setting value as integer
    """
    return _settings_cache.get_int(key, default)


def invalidate_settings_cache(key=None):
    """
    Invalidate settings cache.
    
    Args:
        key (str, optional): Specific key or None for all
    """
    _settings_cache.invalidate(key)


def get_cache_stats():
    """
    Get cache statistics.
    
    Returns:
        dict: Cache stats
    """
    return _settings_cache.get_stats()
