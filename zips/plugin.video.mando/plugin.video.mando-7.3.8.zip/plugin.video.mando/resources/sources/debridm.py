# -*- coding: utf-8 -*-
#generateTokenAndHash Function
import re
import time,ssl,requests,urllib3
from resources.modules import cloudscraper
global global_var,stop_all#global
global_var=[]
stop_all=0
#from  resources.modules.client import get_html
 
from resources.modules.general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,base_header
from  resources.modules import cache
try:
    from resources.modules.general import Addon,get_imdb
except:
  import Addon
type=['movie','tv','torrent']

import urllib,logging,base64,json

from resources.modules import log

try:
    que=urllib.quote_plus
except:
    que=urllib.parse.quote_plus
color=all_colors[112]

def get_secret():
    import ctypes,math
    def from_char_code(e,s):
        return ord(e[s])
    def random_number():
        import random

        ran = random.randrange(10**80)
        myhex = "%064x" % ran

        #limit string to 64 characters
        myhex = myhex[:8]

        return myhex
    def get_unix_time():
        import time

        return int(time.time()) 
    def calc_value_alg(t,n,const):
        temp=t^n

        t=ctypes.c_long((temp*const)).value
        t4=ctypes.c_long(t<<5).value

        x32 = t & 0xffffffff   # convert to 32-bit unsigned value

        t5=ctypes.c_long(x32 >> 27  ).value

        t6=t4 | t5

        return t6
    def slice(e,t):
        a =math.floor(len(e) / 2)
        print (a)
        s = e[0: a]
        print (s)
        n = e[a:]
        print (n)
        i = t[0: a]
        print (i)
        o = t[a:]
        print (o)
        l = ""
        for e in range(0,a):
            l += s[e] + i[e]
        
        temp=l + (o[::-1] + n[::-1])
        print(temp)
        return temp
                    
    def generateHash(e):
        t=int(3735928559) ^ int(len(e))
        
        
        t= ctypes.c_long(t).value
        

        a = 1103547991 ^ len(e)
      
        for s in range(len(e)):
            n =from_char_code(e,s) 
            
            t=calc_value_alg(t,n,2654435761)
            
            
            
            #a=(a ^ n*1597334677) << 5 | a >> 27
            a=calc_value_alg(a,n,1597334677)
            
            
        

        t_o=t
        t =ctypes.c_long( t + ctypes.c_long(a* 1566083941).value | 0).value
        

        a =ctypes.c_long(  a + ctypes.c_long(t* 2024237689).value | 0).value

        return ((ctypes.c_long(t ^ a).value& 0xffffffff) >> 0)
                
    e=random_number()
    t=get_unix_time()


    a=str(e)+'-'+str(t)

  
    s=generateHash(a)
    s=hex(s).replace('0x','')

    n = generateHash("debridmediamanager.com%%fe7#td00rA3vHz%VmI-" + e)
    n=hex(n).replace('0x','')
 
    i=slice(s,n)
    dmmProblemKey=a
    solution=i
    return dmmProblemKey,solution
dmmProblemKey,solution=get_secret()


def chack_hashed(hash_list,imdbId):
    
    headers = {
        'accept': '*/*',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        # 'cookie': 'cf_clearance=grPLmX3Ze9UWq3CvKGHD4R1XkQ9eVYlhnaUkedG2I.w-1733035082-1.2.1.1-lKTl0dI5l1dGaywV8aofkgH9QV7DyFljnNItjmmKF0PYbQ51a5XDG5GTs6kZnJxJAdRrSgwYNzH48QC0wrD9ZdHnUxDLSnZHvv_nwqADoyD._1dYOJFBjs32YAU5qnyW7SThGNqcoRWcoAwb9dT68aMTM83EJH0v3WoqK5xATQBZ5Iv5PmemjQfq3ODkZVn20In5wtvHdvmBOV.95fJL7oFkOpnDEELtFuZ1NEzTB3ydU0uaih4a57Lf4Y03pzUW8w4Qu9015La3qRGdRingkNMoZxXtj3bpkjmpU2D1UpsuvZN.5cj.WCGL27wvJbajyIxk5ODLVMn2PyrwXA2dWPdeNrZgnraV5KkJsyfvgIg_nZPIlK9IBGUmI_8TJrmWjbm0UPXQ_WRl1zJxYqKD4w',
        'dnt': '1',
        'origin': 'https://debridmediamanager.com',
        'pragma': 'no-cache',
        'priority': 'u=1, i',
        
        'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    }
    dmmProblemKey,solution=get_secret()
    json_data = {
        'imdbId': imdbId,
        'hashes': hash_list,
        'dmmProblemKey': dmmProblemKey,
        'solution': solution,
    }

    r = get_html('https://debridmediamanager.com/api/availability/check', headers=headers, json=json_data)

    return r
    
class TLSAdapter(requests.adapters.HTTPAdapter):
    def init_poolmanager(self, connections, maxsize, block=False):
        ctx = ssl.create_default_context()
        ctx.set_ciphers('DEFAULT@SECLEVEL=1')
        ctx.check_hostname = False
        self.poolmanager = urllib3.poolmanager.PoolManager(num_pools=connections,
                                                           maxsize=maxsize,
                                                           block=block,
                                                           ssl_version=ssl.PROTOCOL_TLSv1_2,
                                                           ssl_context=ctx)
def get_html(url,headers={},json=None):
    
    
    scraper = cloudscraper.create_scraper()  # returns a CloudScraper instance
    scraper.mount('https://', TLSAdapter())
    if json:
        response = scraper.post(url,headers=headers,json=json).json()
    else:
        response = scraper.get(url,headers=headers).json()
    return response
def get_links(tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    imdb_id=cache.get(get_imdb, 999,tv_movie,id,table='pages')
        
    
    added_season=''
    if tv_movie=='tv':
    
        added_season='&seasonNum='+str(season)
    dmmProblemKey,solution=get_secret()
    o_url=f'https://debridmediamanager.com/api/torrents/{tv_movie}?imdbId={imdb_id}{added_season}&dmmProblemKey={dmmProblemKey}&solution={solution}&onlyTrusted=false&maxSize=0&page=%s'
    
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9',
        
        'priority': 'u=1, i',
        
        'sec-ch-ua': '"Microsoft Edge";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0',
    }
    for page in range(4):
        url=o_url%str(page)
        
        x=get_html(url,headers=headers)
        
        for results in x['results']:

                if stop_all==1:
                    break
                nam=results['title']
                size=(float(results['fileSize'])/(1024))
     
                links=results['hash']
                lk='magnet:?xt=urn:btih:%s&dn=%s'%(links,que(original_title))
                if '4k' in nam:
                      res='2160'
                elif '2160' in nam:
                      res='2160'
                elif '1080' in nam:
                          res='1080'
                elif '720' in nam:
                      res='720'
                elif '480' in nam:
                      res='480'
                elif '360' in nam:
                      res='360'
                else:
                      res='HD'
                max_size=int(Addon.getSetting("size_limit"))
                
                
                if (size)<max_size:
                   
                    all_links.append((nam,lk,str(size),res))

                    global_var=all_links
    return global_var