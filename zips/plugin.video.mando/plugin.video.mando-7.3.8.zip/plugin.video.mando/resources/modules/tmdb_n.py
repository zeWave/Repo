# EXTREME PERFORMANCE TMDB MODULE - Optimized for speed above all else

import time, sys, json, os
from resources.modules.client import get_html
from resources.modules import cache, log
import xbmcplugin, xbmcgui, xbmc,xbmcvfs
from urllib.parse import urlencode
from resources.modules.general import addon_id
import xbmcaddon
from sqlite3 import dbapi2 as database
from concurrent.futures import ThreadPoolExecutor
import threading
from  resources.modules.public import lang
# Constants
Addon = xbmcaddon.Addon()
user_dataDir = Addon.getSetting("user_data_dir") if Addon.getSetting("user_data_dir") else os.path.join(xbmcvfs.translatePath(Addon.getAddonInfo('profile')))
cacheFile = os.path.join(user_dataDir, 'database.db')
from resources.modules.public import get_imdb_key
tmdb_key=get_imdb_key()

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])

# Global in-memory caches - super fast access
MEMORY_CACHE = {}
WATCHED_STATUS = {}
PRELOADED_PAGES = {}

# Preload popular movies on module import
def preload_popular_movies():
    try:
        # Only preload if not already in memory
        cache_key = f"movie_list_http://api.themoviedb.org/3/movie/popular?api_key={tmdb_key}&language={lang}&page=1"
        if cache_key not in MEMORY_CACHE:
            url = f"http://api.themoviedb.org/3/movie/popular?api_key={tmdb_key}&language={lang}&page=1"
            # Make a background thread to fetch data
            threading.Thread(target=lambda: MEMORY_CACHE.update({cache_key: get_html(url).json()}), daemon=True).start()
    except:
        pass

# Start preloading immediately
preload_popular_movies()

# Minimal lookup of genre data to avoid API calls
GENRE_MAP = {
    'movie': {
        28: 'אקשן', 12: 'הרפתקאות', 16: 'אנימציה', 35: 'קומדיה', 80: 'פשע',
        99: 'דוקומנטרי', 18: 'דרמה', 10751: 'משפחה', 14: 'פנטזיה', 36: 'היסטוריה',
        27: 'אימה', 10402: 'מוזיקה', 9648: 'מסתורין', 10749: 'רומנטיקה', 878: 'מדע בדיוני',
        10770: 'סרט טלוויזיה', 53: 'מתח', 10752: 'מלחמה', 37: 'מערבון'
    },
    'tv': {
        10759: 'אקשן והרפתקאות', 16: 'אנימציה', 35: 'קומדיה', 80: 'פשע', 99: 'דוקומנטרי',
        18: 'דרמה', 10751: 'משפחה', 10762: 'ילדים', 9648: 'מסתורין', 10763: 'חדשות',
        10764: 'ריאליטי', 10765: 'מדע בדיוני ופנטזיה', 10766: 'אופרת סבון', 10767: 'תוכניות אירוח',
        10768: 'מלחמה ופוליטיקה', 37: 'מערבון'
    }
}

class tmdb:
    """Ultra optimized TMDB class for maximum speed"""
    def __init__(self, action, url, heb_name='', original_title='', id=''):
        self.url = url
        
        self.tv_movie = 'movie' if '/movie' in url else 'tv'
        self.heb_name = heb_name
        self.original_title = original_title
        self.id = id
        self.all_lists = []
        
        # Immediately execute the requested action
        if action == 'get_movies':
            self.get_movies()
        elif action == 'get_seasons':
            self.get_seasons()
        elif action == 'get_episodes':
            self.get_episodes()
    
    def get_cached_data(self, key):
        """Fast data retrieval from memory only"""
        return MEMORY_CACHE.get(key)
    
    def set_cached_data(self, key, data):
        """Store data in memory only"""
        MEMORY_CACHE[key] = data
    
    def get_movies(self):
        """Main entry point for movie listing - extreme performance version"""
        # Fetch minimal movie data
        self.load_movies_fast()
        
        # Add items to Kodi
        self.add_movie_listings()
    
    def load_movies_fast(self):
        """Load movie data with absolute minimum processing"""
        cache_key = f"movie_list_{self.url}"
        
        # Try to get cached data first (memory only for speed)
        data = self.get_cached_data(cache_key)
        
        if not data:
            # DIRECT API CALL - no database caching for speed
            try:
                data = get_html(self.url).json()
                self.set_cached_data(cache_key, data)
            except Exception as e:
                log.warning(f"Error loading movies: {e}")
                data = {'results': []}
        
        self.raw_data = data
    
    def get_genres_string(self, genre_ids):
        """Fast genre lookup from memory"""
        if not genre_ids:
            return ""
        
        genre_names = []
        for genre_id in genre_ids:
            genre_name = GENRE_MAP.get(self.tv_movie, {}).get(genre_id)
            if genre_name:
                genre_names.append(genre_name)
        
        return " / ".join(genre_names)
    
    def get_watched_status(self):
        """Get watched status with extreme optimization"""
        # Check if we've already loaded watched data
        if self.tv_movie in WATCHED_STATUS:
            return WATCHED_STATUS[self.tv_movie]
        
        # Fast DB query - get all at once
        try:
            dbcon = database.connect(cacheFile)
            dbcur = dbcon.cursor()
            dbcur.execute("CREATE TABLE IF NOT EXISTS playback (name TEXT, tmdb TEXT, season TEXT, episode TEXT, playtime TEXT, total TEXT, free TEXT)")
            
            if self.tv_movie == 'tv':
                dbcur.execute("SELECT episode, playtime, total FROM playback WHERE tmdb = ? AND season = ?", 
                             (self.id, self.season))
            else:
                dbcur.execute("SELECT tmdb, playtime, total FROM playback")
            
            results = dbcur.fetchall()
            dbcon.close()
            
            # Build lookup dict
            watched = {}
            for row in results:
                if self.tv_movie == 'tv':
                    episode, playtime, total = row
                    watched[str(episode)] = {'resume': playtime, 'totaltime': total}
                else:
                    tmdb, playtime, total = row
                    watched[str(tmdb)] = {'resume': playtime, 'totaltime': total}
            
            # Cache in memory
            WATCHED_STATUS[self.tv_movie] = watched
            
            return watched
        except:
            return {}
    def get_watch_indicator(self, tmdb_id, watched_data, episode=0):
        """Minimal watch indicator calculation"""
        if self.tv_movie == 'tv':
            key = str(episode)
        else:
            key = str(tmdb_id)
        
        # Default - no indicator
        indicator = ''
        
        time_to_save = int(Addon.getSetting("time_to_save") or "90")
        
        if key in watched_data:
            resume = watched_data[key]['resume']
            total = watched_data[key]['totaltime']
            
            # Calculate percentage
            if '%' in str(resume):
                percentage = float(resume.replace('%', ''))
            else:
                try:
                    percentage = (float(resume) * 100) / float(total)
                except (ValueError, ZeroDivisionError):
                    percentage = 0
            
            # Format indicator based on percentage
            if percentage >= time_to_save:
                indicator = ' [COLOR yellow][I]√[/I][/COLOR] '
            elif percentage > 1:
                indicator = f' [COLOR yellow][I]{int(percentage)}%[/I][/COLOR] '
        
        return indicator
    
    def create_movie_list_item(self, movie, watched_data):
        """Create list item with all required metadata but minimal processing"""
        # Basic movie info
        movie_id = str(movie['id'])
        title = movie.get('title', movie.get('name'))
        original_title = movie.get('original_title', '')
        overview = movie.get('overview', '')
        poster_path = movie.get('poster_path', '')
        backdrop_path = movie.get('backdrop_path', '')
        genre_ids = movie.get('genre_ids', [])
        rating = movie.get('vote_average', 0)
        votes = movie.get('vote_count', 0)
        release_date = movie.get('release_date', movie.get('first_air_date',''))
        
        # Generate URLs for images
        poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
        fanart_url = f"https://image.tmdb.org/t/p/w1280{backdrop_path}" if backdrop_path else ""
        
        # Get year from release date
        year = release_date.split('-')[0] if release_date else ""
        
        # Process genres
        genre = self.get_genres_string(genre_ids)
        
        # Get watched status indicator
        watch_indicator = self.get_watch_indicator(movie_id, watched_data)
        
        # Set title with watch indicator
        display_title = title
        if watch_indicator:
            display_title = f"{watch_indicator}{title}"
        
        # Create list item
        listitem = xbmcgui.ListItem(offscreen=True)
        listitem.setLabel(display_title)
        
        # Default art and paths
        art = {
            'poster': poster_url,
            'fanart': fanart_url, 
            'icon': poster_url,
            'thumb': fanart_url
        }
        
        # Create a trailer URL
        trailer_url = f"plugin://{addon_id}?mode=25&id={movie_id}&url={self.tv_movie}"
        
        # Check if we need extra data based on settings
        extra_data_enabled = Addon.getSetting("extra_data") == 'true'
        
        # If extra data is enabled, fetch or use cached
        if extra_data_enabled:
            # Try to get from cache first
            cache_key = f"movie_extra_{movie_id}"
            extra_data = self.get_cached_data(cache_key)
            
            if not extra_data:
                # Prepare background fetch for extra data without waiting
                self.fetch_extra_data_background(movie_id)
                
                # Set a flag to indicate we need to fetch extra data later
                needs_extra = True
            else:
                # We have extra data, add it to art and metadata
                needs_extra = False
                self.add_extra_data_to_item(listitem, extra_data, art)
        else:
            needs_extra = False
            
        # Set basic art
        listitem.setArt(art)
        
        # Set info based on Kodi version
        if KODI_VERSION > 19:
            # Use new InfoTag API
            info_tag = listitem.getVideoInfoTag()
            info_tag.setMediaType('movie')
            info_tag.setTitle(display_title)
            info_tag.setPlot(overview)
            info_tag.setOriginalTitle(original_title)
            info_tag.setTrailer(trailer_url)
            
            if year and year.isdigit():
                info_tag.setYear(int(year))
                
            info_tag.setRating(float(rating) if rating else 0)
            info_tag.setVotes(int(votes) if votes else 0)
            
            # Set genre if available
            if genre:
                info_tag.setGenres(genre.split(' / '))
                
            # Set unique IDs
            info_tag.setUniqueIDs({'tmdb': movie_id})
        else:
            # Older Kodi versions
            info_labels = {
                'title': display_title,
                'plot': overview,
                'originaltitle': original_title,
                'year': year,
                'rating': float(rating) if rating else 0,
                'votes': votes,
                'trailer': trailer_url,
                'genre': genre,
                'mediatype': 'movie'
            }
            listitem.setInfo('Video', info_labels)
            listitem.setUniqueIDs({'tmdb': movie_id})
        
        # Build context menu
        context_menu = self.build_context_menu(movie_id, title, original_title, trailer_url)
        listitem.addContextMenuItems(context_menu, replaceItems=False)
        
        # Create URL parameters for this movie
        if 'page=' in self.url:
            link = self.url.split('page=')[0]
            page_no = self.url.split('page=')[1]
        else:
            link = self.url
            page_no = '1'
        if self.tv_movie=='movie':
            mode=15
            isfolder=False
        else:
            mode=16
            isfolder=True
        params = {
            'iconimage': poster_url,
            'fanart': fanart_url,
            'description': overview,
            'url': link + 'page=' + str(int(page_no) + 1),
            'name': title,
            'season': ' ',
            'episode': ' ',
            'heb_name': title,
            'original_title': original_title,
            'id': movie_id,
            'tmdbid': movie_id,
            'eng_name': title,
            'show_original_year': year,
            'data': year,
            'mode': mode  # Movie playback mode
        }
        
        # Convert any complex data for URL
        if extra_data_enabled and not needs_extra:
            # Create minimal video data
            video_data = {
                'title': title,
                'plot': overview,
                'OriginalTitle': original_title,
                'year': year,
                'genre': genre,
                'rating': str(rating),
                'trailer': trailer_url,
                'mediatype': 'movie'
            }
            params['video_data'] = json.dumps(video_data)
        
        url = 'plugin://plugin.video.mando/?' + urlencode(params)
        
        return url, listitem, isfolder
    
    def fetch_extra_data_background(self, movie_id):
        """Start a background thread to fetch extra movie data"""
        cache_key = f"movie_extra_{movie_id}"
        
        # Don't start a new thread if already fetching
        if cache_key + "_fetching" in MEMORY_CACHE:
        
            return
            
        # Mark as fetching to prevent duplicate requests
        MEMORY_CACHE[cache_key + "_fetching"] = True
        
        # Start a background thread
        threading.Thread(target=self.fetch_movie_extra_data, args=(movie_id,), daemon=True).start()
    
    def fetch_movie_extra_data(self, movie_id):
        """Fetch additional movie data in background thread"""
        cache_key = f"movie_extra_{movie_id}"
        
        try:
            # Fetch detailed data from API
            url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={tmdb_key}&language=en&append_to_response=credits,videos,release_dates"
            
            data = get_html(url).json()
            
            # Extract essential data
            extra_data = {
                'imdb_id': data.get('imdb_id', ''),
                'runtime': data.get('runtime', 90) * 60,  # Convert to seconds
                'mpaa': '',
                'tagline': data.get('tagline', ''),
                'studio': '',
                'premiered': data.get('release_date', ''),
                'country': []
            }
            
            # Get MPAA rating
            release_dates = data.get('release_dates', {}).get('results', [])
            for country_data in release_dates:
                if country_data.get('iso_3166_1') == 'US':
                    for release in country_data.get('release_dates', []):
                        if release.get('certification'):
                            extra_data['mpaa'] = release.get('certification')
                            break
                    if extra_data['mpaa']:
                        break
            
            # Get studio
            production_companies = data.get('production_companies', [])
            if production_companies:
                extra_data['studio'] = production_companies[0].get('name', '') if production_companies else ''
            
            # Get countries
            production_countries = data.get('production_countries', [])
            if production_countries:
                extra_data['country'] = [country.get('name', '') for country in production_countries]
            
            # Process cast if available
            cast = []
            credits = data.get('credits', {})
            if credits and 'cast' in credits:
                cast = [
                    {
                        'name': actor.get('name', ''),
                        'role': actor.get('character', ''),
                        'thumbnail': f"https://image.tmdb.org/t/p/w185{actor.get('profile_path', '')}" if actor.get('profile_path') else ''
                    }
                    for actor in credits.get('cast', [])[:10]  # Limit to top 10
                ]
            extra_data['cast'] = cast
            
            # Process crew (director, writer)
            directors = []
            writers = []
            for crew_member in credits.get('crew', []):
                if crew_member.get('job') == 'Director':
                    directors.append(crew_member.get('name', ''))
                elif crew_member.get('job') in ('Writer', 'Screenplay', 'Author'):
                    writers.append(crew_member.get('name', ''))
            
            extra_data['director'] = ', '.join(directors)
            extra_data['writer'] = ', '.join(writers)
            
            # Process videos for trailer
            for video in data.get('videos', {}).get('results', []):
                if video.get('type') in ('Trailer', 'Teaser') and video.get('site') == 'YouTube':
                    extra_data['trailer'] = f"plugin://plugin.video.youtube/play/?video_id={video.get('key', '')}"
                    break
            
            # Fetch fanart.tv data if client key available
            fanart_client_key = Addon.getSetting("fanart_client_key")
            if fanart_client_key:
                try:
                    fanart_api_key = 'a7ad21743fd710fccb738232f2fbdcfc'
                    fanart_url = f"http://webservice.fanart.tv/v3/movies/{movie_id}?api_key={fanart_api_key}&client_key={fanart_client_key}"
                    fanart_data = get_html(fanart_url).json()
                    
                    # Initialize art data
                    art_data = {
                        'clearlogo': '',
                        'clearart': '',
                        'banner': '',
                        'landscape': '',
                        'discart': '',
                        'keyart': ''
                    }
                    
                    # Process logos
                    if 'hdmovielogo' in fanart_data:
                        logos = [item['url'] for item in fanart_data['hdmovielogo'] if item.get('lang') == 'en']
                        if logos:
                            art_data['clearlogo'] = logos[0]
                    
                    # Process clearart
                    if 'hdmovieclearart' in fanart_data:
                        clearart = [item['url'] for item in fanart_data['hdmovieclearart'] if item.get('lang') == 'en']
                        if clearart:
                            art_data['clearart'] = clearart[0]
                    
                    # Process banners
                    if 'moviebanner' in fanart_data:
                        banners = [item['url'] for item in fanart_data['moviebanner'] if item.get('lang') == 'en']
                        if banners:
                            art_data['banner'] = banners[0]
                    
                    # Process landscape/background
                    if 'moviebackground' in fanart_data:
                        backgrounds = [item['url'] for item in fanart_data['moviebackground']]
                        if backgrounds:
                            art_data['landscape'] = backgrounds[0]
                    
                    # Process discart
                    if 'moviedisc' in fanart_data:
                        discs = [item['url'] for item in fanart_data['moviedisc']]
                        if discs:
                            art_data['discart'] = discs[0]
                    
                    # Process keyart - matches movies.py implementation
                    if 'movieposter' in fanart_data:
                        posters = [item['url'] for item in fanart_data['movieposter'] if item.get('lang') == 'en']
                        if posters:
                            art_data['keyart'] = posters[0]
                    
                    # Add art data to extra data
                    extra_data.update(art_data)
                    
                except Exception as e:
                    log.warning(f"Error fetching fanart.tv data: {e}")
            
            # Save to memory cache
            self.set_cached_data(cache_key, extra_data)
            
            # Remove fetching flag
            if cache_key + "_fetching" in MEMORY_CACHE:
                del MEMORY_CACHE[cache_key + "_fetching"]
                
        except Exception as e:
            log.warning(f"Error fetching extra data for movie {movie_id}: {e}")
            
            # Remove fetching flag
            if cache_key + "_fetching" in MEMORY_CACHE:
                del MEMORY_CACHE[cache_key + "_fetching"]
    
    def add_extra_data_to_item(self, listitem, extra_data, art):
        """Add extra metadata to listitem"""
        # Update art with fanart.tv data
        for art_type in ['clearlogo', 'clearart', 'banner', 'landscape', 'discart', 'keyart']:
            if art_type in extra_data and extra_data[art_type]:
                art[art_type] = extra_data[art_type]
       
        # Re-apply the updated art
        listitem.setArt(art)
        
        # Update info tag with extra metadata
        if KODI_VERSION > 19:
            info_tag = listitem.getVideoInfoTag()
            
            # Set additional data
            if 'premiered' in extra_data:
                info_tag.setPremiered(extra_data['premiered'])
                
            if 'tagline' in extra_data:
                info_tag.setTagLine(extra_data['tagline'])
                
            if 'mpaa' in extra_data:
                info_tag.setMpaa(extra_data['mpaa'])
                
            if 'runtime' in extra_data:
                info_tag.setDuration(int(extra_data['runtime']))
                
            if 'studio' in extra_data and extra_data['studio']:
                info_tag.setStudios((extra_data['studio'],))
                
            if 'writer' in extra_data and extra_data['writer']:
                info_tag.setWriters(extra_data['writer'].split(', '))
                
            if 'director' in extra_data and extra_data['director']:
                info_tag.setDirectors(extra_data['director'].split(', '))
                
            if 'country' in extra_data and extra_data['country']:
                info_tag.setCountries(extra_data['country'])
                
            if 'imdb_id' in extra_data and extra_data['imdb_id']:
                # Update unique IDs with IMDb
                unique_ids = {'tmdb': info_tag.getUniqueID('tmdb')}
                unique_ids['imdb'] = extra_data['imdb_id']
                info_tag.setUniqueIDs(unique_ids)
                
            # Set cast if available
            if 'cast' in extra_data and extra_data['cast']:
                cast_list = []
                for cast_item in extra_data['cast']:
                    cast_list.append(xbmc.Actor(
                        name=cast_item['name'],
                        role=cast_item['role'],
                        thumbnail=cast_item['thumbnail']
                    ))
                info_tag.setCast(cast_list)
        else:
            # For Kodi 18 and below, update infoLabels
            info_labels = listitem.getVideoInfoTag().getAsDict() if hasattr(listitem, 'getVideoInfoTag') else {}
            
            # Update fields
            if 'premiered' in extra_data:
                info_labels['premiered'] = extra_data['premiered']
                
            if 'tagline' in extra_data:
                info_labels['tagline'] = extra_data['tagline']
                
            if 'mpaa' in extra_data:
                info_labels['mpaa'] = extra_data['mpaa']
                
            if 'runtime' in extra_data:
                info_labels['duration'] = int(extra_data['runtime'])
                
            if 'studio' in extra_data:
                info_labels['studio'] = extra_data['studio']
                
            if 'writer' in extra_data:
                info_labels['writer'] = extra_data['writer']
                
            if 'director' in extra_data:
                info_labels['director'] = extra_data['director']
                
            listitem.setInfo('Video', info_labels)
            
            # Update unique IDs
            if 'imdb_id' in extra_data and extra_data['imdb_id']:
                unique_ids = listitem.getUniqueID('tmdb')
                unique_ids['imdb'] = extra_data['imdb_id']
                listitem.setUniqueIDs(unique_ids)
                
            # Set cast
            if 'cast' in extra_data and extra_data['cast']:
                listitem.setCast(extra_data['cast'])
    
    def build_context_menu(self, movie_id, title, original_title, trailer_url):
        """Build context menu items"""
        context_menu = [
            ('[I]Info[/I]', 'Action(Info)'),
            ('Queue', 'Action(Queue)')
        ]
        
        # Add additional context menu items based on settings
        if Addon.getSetting("play_trailer") == 'true':
            context_menu.append(('[I]Trailer[/I]', f'PlayMedia({trailer_url})'))
            
        if Addon.getSetting("cast") == 'true':
            context_menu.append(('[I]Cast[/I]', f'ActivateWindow(10025,"plugin://{addon_id}/?mode=177&url={self.tv_movie}&id={movie_id}&season=%20&episode=%20",return)'))
        
        if Addon.getSetting("settings_content") == 'true':
            context_menu.append(('Settings', f'RunPlugin(plugin://{addon_id}/?mode=151&url=www)'))
        
        if Addon.getSetting("trakt_manager") == 'true':
            context_menu.append(('Trakt Manager', f'RunPlugin(plugin://{addon_id}/?url={movie_id}&mode=150&name={original_title}&data={self.tv_movie})'))
        
        if Addon.getSetting("trakt_watched") == 'true':
            context_menu.append(('[I]Mark as Watched[/I]', f'RunPlugin(plugin://{addon_id}/?url=www&original_title=add&mode=65&name={self.tv_movie}&id={movie_id}&season=%20&episode=%20)'))
        
        if Addon.getSetting("trakt_unwatched") == 'true':
            context_menu.append(('[I]Mark as Unwatched[/I]', f'RunPlugin(plugin://{addon_id}/?url=www&original_title=remove&mode=65&name={self.tv_movie}&id={movie_id}&season=%20&episode=%20)'))
        
        if Addon.getSetting("clear_Cache") == 'true':
            context_menu.append(('[I]Clear Cache[/I]', f'RunPlugin(plugin://{addon_id}/?url=www&mode=35)'))
            
        return context_menu
    
    def add_movie_listings(self):
        """Add movie listings to Kodi with extreme optimization"""
        # Get movie results
        results = self.raw_data.get('results', [])
        if not results:
            return
            
        # Get watched data
        watched_data = self.get_watched_status()
        
        # Create list items
        items = []
        for movie in results:
            item = self.create_movie_list_item(movie, watched_data)
            items.append(item)
        
        # Add pagination items if needed
        current_page = self.raw_data.get('page', 1)
        total_pages = self.raw_data.get('total_pages', 1)
        
        if current_page < total_pages:
            # Add "Next Page" item
            if 'page=' in self.url:
                base_url = self.url.split('page=')[0]
                next_page = int(self.url.split('page=')[1]) + 1
            else:
                base_url = self.url
                next_page = 2
                
            next_url = base_url + 'page=' + str(next_page)
            
            # Create Next Page item
            listitem = xbmcgui.ListItem('[COLOR aqua][I]עמוד הבא[/I][/COLOR]', offscreen=True)
            listitem.setArt({
                'icon': 'https://www.shutterstock.com/image-vector/curled-corner-red-text-next-260nw-203435044.jpg',
            })
            
            params = {
                'url': next_url,
                'name': '[COLOR aqua][I]עמוד הבא[/I][/COLOR]',
                'mode': 14,
            }
            
            next_url = 'plugin://plugin.video.mando/?' + urlencode(params)
            items.append((next_url, listitem, True))
        
        # Add all items in a single batch
        xbmcplugin.addDirectoryItems(int(sys.argv[1]), items, len(items))
        
        # Set content type and finish
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)
    
    # TV SHOW FUNCTIONS
    def get_seasons(self):
        """Get TV show seasons"""
        # Fetch show data
        self.load_show_data()
        
        # Add seasons
        self.add_season_listings()
    
    def load_show_data(self):
        """Load TV show data"""
        cache_key = f"tv_show_{self.url}"
        
        # Try memory cache first
        data = self.get_cached_data(cache_key)
        
        if not data:
            # Direct API call
            try:
                data = get_html(self.url).json()
                self.set_cached_data(cache_key, data)
            except Exception as e:
                log.warning(f"Error loading show data: {e}")
                data = {}
        
        self.show_data = data
    
    def add_season_listings(self):
        """Add season listings to Kodi"""
        if not hasattr(self, 'show_data') or not self.show_data:
            return
            
        # Extract show info
        show_id = self.id
        show_name = self.show_data.get('name', '')
        original_name = self.show_data.get('original_name', '')
        overview = self.show_data.get('overview', '')
        backdrop_path = self.show_data.get('backdrop_path', '')
        fanart = f"https://image.tmdb.org/t/p/w1280{backdrop_path}" if backdrop_path else ""
        
        # Get first air date for year
        first_air_date = self.show_data.get('first_air_date', '')
        year = first_air_date.split('-')[0] if first_air_date else ""
        
        # Get seasons
        seasons = self.show_data.get('seasons', [])
        
        # Create items list
        items = []
        
        for season in seasons:
            # Skip specials (season 0)
            if season.get('season_number', 0) <= 0:
                continue
                
            # Get season data
            season_number = season.get('season_number', 0)
            season_name = f"עונה {season_number}"
            episode_count = season.get('episode_count', 0)
            season_poster = season.get('poster_path', '')
            poster = f"https://image.tmdb.org/t/p/w500{season_poster}" if season_poster else ""
            air_date = season.get('air_date', '')
            season_year = air_date.split('-')[0] if air_date else year
            
            # Create list item
            listitem = xbmcgui.ListItem(season_name, offscreen=True)
            
            # Set art
            listitem.setArt({
                'poster': poster,
                'fanart': fanart,
                'icon': poster,
                'thumb': poster
            })
            
            # Set info
            if KODI_VERSION > 19:
                info_tag = listitem.getVideoInfoTag()
                info_tag.setMediaType('season')
                info_tag.setTitle(season_name)
                info_tag.setPlot(overview)
                info_tag.setTvShowTitle(show_name)
                info_tag.setSeason(season_number)
        
                if season_year and season_year.isdigit():
                    info_tag.setYear(int(season_year))
            else:
                listitem.setInfo('Video', {
                    'title': season_name,
                    'plot': overview,
                    'tvshowtitle': show_name,
                    'season': season_number,
                    'year': season_year,
                    'mediatype': 'season'
                })
            
            # Set properties
            listitem.setProperty('totalepisodes', str(episode_count))
            
            # Create URL for season
            url = f"https://api.themoviedb.org/3/tv/{show_id}/season/{season_number}?api_key={tmdb_key}&language={lang}&append_to_response=external_ids"
            
            params = {
                'iconimage': poster,
                'fanart': fanart,
                'description': overview,
                'url': url,
                'name': season_name,
                'heb_name': show_name,
                'original_title': original_name,
                'id': show_id,
                'mode': 19,
                'season': str(season_number),
                'episode': ' ',
                'tmdbid': show_id,
                'eng_name': original_name,
                'show_original_year': year
            }
            
            url_params = 'plugin://plugin.video.mando/?' + urlencode(params)
            
            # Add to list
            items.append((url_params, listitem, True))
        
        # Add all items in a single batch
        xbmcplugin.addDirectoryItems(int(sys.argv[1]), items, len(items))
        
        # Set content type and finish
        xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)
    
    def get_episodes(self):
        """Get TV show episodes"""
        # Set season for watched status
        self.season = ''
        
        # Fetch season data
        self.load_season_data()
        
        # Add episodes
        self.add_episode_listings()
    
    def load_season_data(self):
        """Load TV season data"""
        cache_key = f"tv_season_{self.url}"
        
        # Try memory cache first
        data = self.get_cached_data(cache_key)
        
        if not data:
            # Direct API call
            try:
                data = get_html(self.url).json()
                self.set_cached_data(cache_key, data)
            except Exception as e:
                log.warning(f"Error loading season data: {e}")
                data = {}
        
        self.season_data = data
        self.season = str(data.get('season_number', '0'))
    
    def add_episode_listings(self):
        """Add episode listings to Kodi"""
        if not hasattr(self, 'season_data') or not self.season_data:
            return
            
        # Get watched status with season number
        watched_data = self.get_watched_status()
        
        # Get episodes
        episodes = self.season_data.get('episodes', [])
        
        # Get season poster
        season_poster = self.season_data.get('poster_path', '')
        poster = f"https://image.tmdb.org/t/p/w500{season_poster}" if season_poster else ""
        
        # Create items list
        items = []
        
        for episode in episodes:
            # Basic episode info
            episode_number = episode.get('episode_number', 0)
            
            # Get name
            if episode.get('name'):
                title = f"{episode_number} . {episode.get('name')}"
            else:
                title = f"Episode {episode_number}"
            
            # Get metadata
            overview = episode.get('overview', '')
            air_date = episode.get('air_date', '')
            still_path = episode.get('still_path', '')
            still = f"https://image.tmdb.org/t/p/original{still_path}" if still_path else poster
            
            # Color code for future episodes
            is_future = False
            if air_date:
                try:
                    air_date_obj = time.strptime(air_date, '%Y-%m-%d')
                    current_date = time.strptime(time.strftime('%Y-%m-%d'), '%Y-%m-%d')
                    is_future = air_date_obj > current_date
                except:
                    pass
            
            # Get watched status
            watch_indicator = self.get_watch_indicator(self.id, watched_data, episode_number)
            
            # Build display title
            display_title = title
            if watch_indicator:
                display_title = f"{watch_indicator}{title}"
            
            if is_future:
                display_title = f"[COLOR red]{display_title}[/COLOR]"
            
            # Create list item
            listitem = xbmcgui.ListItem(display_title, offscreen=True)
            
            # Set art
            listitem.setArt({
                'thumb': still,
                'icon': poster,
                'poster': poster,
                'fanart': still
            })
            
            # Set info
            if KODI_VERSION > 19:
                info_tag = listitem.getVideoInfoTag()
                info_tag.setMediaType('episode')
                info_tag.setTitle(display_title)
                info_tag.setPlot(f' שודר ב {air_date}\n'+overview)
                info_tag.setTvShowTitle(self.heb_name)
                info_tag.setSeason(int(self.season))
                info_tag.setEpisode(episode_number)
                info_tag.setOriginalTitle(self.original_title)
                
                if air_date:
                    info_tag.setPremiered(air_date)
            else:
                listitem.setInfo('Video', {
                    'title': display_title,
                    'plot': f' שודר ב {air_date}\n'+ overview,
                    'tvshowtitle': self.heb_name,
                    'season': int(self.season),
                    'episode': episode_number,
                    'premiered': air_date,
                    'mediatype': 'episode'
                })
            
            # Create URL for playback
            params = {
                'iconimage': poster,
                'fanart': still,
                'description': overview,
                'url': 'www',
                'name': title,
                'heb_name': self.heb_name,
                'original_title': self.original_title,
                'id': self.id,
                'mode': 15,
                'season': self.season,
                'episode': str(episode_number),
                'tmdbid': self.id,
                'eng_name': self.original_title
            }
            
            url_params = 'plugin://plugin.video.mando/?' + urlencode(params)
            
            # Add to list
            items.append((url_params, listitem, False))
        
        # Add all items in a single batch
        xbmcplugin.addDirectoryItems(int(sys.argv[1]), items, len(items))
        
        # Set content type and finish
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)

# End of file#!/usr/bin/env python3