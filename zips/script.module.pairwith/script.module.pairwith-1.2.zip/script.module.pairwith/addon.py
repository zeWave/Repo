# -*- coding: utf-8 -*-
import time
import xbmc,xbmcaddon
import os
import xbmcgui

import webbrowser
import xbmc
import json
import sys


def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
		function4,
		function5,
		function6,
		function7,
		function8,
		function9,
		function10,
		function11,
		function12,
		function13,
		function14,
		function15,
		function16,
		function17,
		function18,
		#function19,
		#function20,
		#function21
        )
        
    call = dialog.select('[COLOR=red]הגדרת התחברות[/COLOR]', [
	'[COLOR=gold]=== אישור חשבונות Debrid ===[/COLOR]',
	'[COLOR=white](1) ResolveUrl[/COLOR]',
	'[COLOR=white](2) Mando[/COLOR]',
	'[COLOR=white](3) FEN[/COLOR]',
    '[COLOR=gold]=== אישור חשבונות Trakt ===[/COLOR]',
    '[COLOR=white](1) Fen[/COLOR]',
	'[COLOR=white](2) MANDO[/COLOR]',
    '[COLOR=gold]=== הגדרת חשבון Telemedia ===[/COLOR]',
	'[COLOR=white](1) לא פעיל[/COLOR]',
	'[COLOR=white](2) לא פעיל[/COLOR]',])



    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-18]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def function1(): 0

def function2():
    xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")

def function3():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=138&url=www)")

def function4():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)")

def function5():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)")
        
def function6(): 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_authenticate)")

def function7():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=157&url=False)")

def function8():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_authenticate)')

def function9():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_authenticate)')

def function10():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.allmoviesin?mode=157&url=False)")

def function11():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.elementum/trakt/authorize)")

def function12(): 0

def function13():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")

def function14():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=48&url=www)")

def function15():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.directv.com/sports/mlb_schedules' ) )
    else:
        opensite = webbrowser . open('https://www.directv.com/sports/mlb_schedules')		

def function16():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://schedule.boxingscene.com/' ) )
    else:
        opensite = webbrowser . open('https://schedule.boxingscene.com/')	

def function17():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.ufc.com/schedule' ) )
    else:
        opensite = webbrowser . open('http://www.ufc.com/schedule/')

def function18():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://t.me/joinchat/EcAW2RKp5wnCiogp_Fs7mA' ) )
    else:
        opensite = webbrowser . open('https://t.me/joinchat/Hz_GFxEIgPnyeS0NqGv2Kg/')	
		
menuoptions()