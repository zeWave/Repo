import time,xbmcplugin,os,json,sys

from resources.modules.public import *
global CLIENT_ID,CLIENT_SECRET

#trakt api keys
CLIENT_ID = "8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6"
CLIENT_SECRET = "1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426"


addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))
if Addon.getSetting("theme")=='0':
    art_folder='artwork'
    
elif Addon.getSetting("theme")=='1':
    art_folder='artwork_keshav'
elif Addon.getSetting("theme")=='2':
    art_folder='artwork_shinobi'
elif Addon.getSetting("theme")=='3':
    art_folder='artwork_sonic'
elif Addon.getSetting("theme")=='4':
    art_folder='artwork_bob'
    
BASE_LOGO=os.path.join(addonPath, 'resources', art_folder+'/')
file = open(os.path.join(BASE_LOGO, 'fanart.json'), 'r') 
fans= file.read()
file.close()
fanarts=json.loads(fans)
all_fanarts={}
for items in fanarts:
    if 'http' in fanarts[items]:
        all_fanarts[items]=fanarts[items]
    else:
        all_fanarts[items]=(os.path.join(BASE_LOGO, fanarts[items]))
    


def main_menu():


    
    all_d=[]
   
    if Addon.getSetting('movie_world')=='true':
        aa=addDir3(Addon.getLocalizedString(32024),'www',2,BASE_LOGO+'basic.png',all_fanarts['32024'],'Movies')
        all_d.append(aa)
    if Addon.getSetting('tv_world')=='true':
        aa=addDir3(Addon.getLocalizedString(32025),'www',3,BASE_LOGO+'basic.png',all_fanarts['32025'],'TV')
        all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard 4K One Click Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/4ksection.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','4K One Click Section',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard One Click Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/real.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','1080 One Click Section',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Sports Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/sport.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Sports',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Non Debrid Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/free.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Non Debrid Section',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Documentaries Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/docs.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Documentaries',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Kids Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/kids.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Kids',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Music Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/music/musicvidsall.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Music',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Stand Up Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/stand-up-comedy.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Stand Up',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Anime Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/movie/anime.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Anime',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Soaps Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/Soap.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Soaps',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Live TV Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/livetv.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Live TV',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Apps Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/apps.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Apps',search_db='')
    all_d.append(aa)
    if Addon.getSetting('search')=='true':
        aa=addDir3(Addon.getLocalizedString(32020),'www',5,BASE_LOGO+'basic.png',all_fanarts['32020'],'Search')
        all_d.append(aa)
    if Addon.getSetting('search_history')=='true':
        aa=addDir3(Addon.getLocalizedString(32021),'both',143,BASE_LOGO+'basic.png',all_fanarts['32021'],'TMDB')
        all_d.append(aa)
    if Addon.getSetting('debrid_select')=='0':
        if Addon.getSetting('my_rd_history')=='true':
            aa=addDir3(Addon.getLocalizedString(32031),'1',168,BASE_LOGO+'basic.png',all_fanarts['32031'],'TMDB')
            all_d.append(aa)
        if Addon.getSetting('rd_Torrents')=='true':
            aa=addDir3(Addon.getLocalizedString(32032),'1',169,BASE_LOGO+'basic.png',all_fanarts['32032'],'TMDB')
            all_d.append(aa)
    if Addon.getSetting('resume_watching')=='true':		
        aa=addDir3(Addon.getLocalizedString(32030),'both',158,BASE_LOGO+'basic.png',all_fanarts['32030'],'TMDB')
        all_d.append(aa)
    if Addon.getSetting('last_link_played')=='true':
        aa=addDir3(Addon.getLocalizedString(32022),'www',144,BASE_LOGO+'basic.png',all_fanarts['32022'],'Last Played') 
        all_d.append(aa)
    if Addon.getSetting('trakt')=='true':
        aa=addDir3(Addon.getLocalizedString(32027),'www',114,BASE_LOGO+'basic.png',all_fanarts['32027'],'TV')
        all_d.append(aa)
    if Addon.getSetting('settings')=='true':
        aa=addNolink( Addon.getLocalizedString(32029), id,151,False,fanart=all_fanarts['32029'], iconimage=BASE_LOGO+'basic.png',plot='',dont_place=True)
        all_d.append(aa)
    if Addon.getSetting('whats_new')=='true':
        aa=addNolink(Addon.getLocalizedString(32028) , id,149,False,fanart=all_fanarts['32028'], iconimage=BASE_LOGO+'basic.png',plot='',dont_place=True)
        all_d.append(aa)
    if Addon.getSetting('scraper_check')=='true':
        aa=addDir3( Addon.getLocalizedString(32034), id,172,BASE_LOGO+'basic.png',all_fanarts['32034'],'Test')
        
        all_d.append(aa)
    
    #Ghost
    #place your Jen playlist here:
    #dulpicate this line with your address
    #aa=addDir3('Name', 'Your Jen Address',189,'Iconimage','fanart','Description',search_db='Your Search db Address')
    #all_d.append(aa)
    #'https://narcacist.com/Jen4k/4ksection.json'
    mypass=""
    key='zWrite'
    mypass=crypt(mypass,key)
        
    #place your MicroJen playlist here:
    #dulpicate this line with your address
    #aa=addDir3('Name', 'Your Jen Address',189,'Iconimage','fanart','Description',search_db='Your Search db Address')
    #all_d.append(aa)
    #aa=addDir3('MicroJen', "https://bitbucket.org/Mad-Eric/textfiles/raw/master/NewMav/MavHome.json",189,'https://www.nylas.com/wp-content/uploads/JSON_Blog_Hero.png','https://i.ytimg.com/vi/9N6a-VLBa2I/maxresdefault.jpg','MicroJen')
    #all_d.append(aa)
    
    if Addon.getSetting('debug')=='true':
        aa=addDir3( 'Unit tests', 'www',181,'https://lh3.googleusercontent.com/proxy/Ia9aOfcgtzofMb0urCAs8NV-4RRhcIVST-Gqx9GI9RLsx7IJe_5jBqjfdsJcOO3QIV3TT-uiF2nKmyYCX0vj5UPR4iW1iHXgZylE8N8wyNgRLw','https://i.ytimg.com/vi/3wLqsRLvV-c/maxresdefault.jpg','Test')
        
        all_d.append(aa)
    found=False
    for i in range(0,10):
        if Addon.getSetting('imdb_user_'+str(i))!='':
            found=True
            break
    if found:
        aa=addDir3(Addon.getLocalizedString(32309),'www',183,BASE_LOGO+'basic.png',all_fanarts['32309'],'Imdb')
        all_d.append(aa)
    
    
    if Addon.getSetting("stop_where")=='0':
            xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    
    
def movie_world():
    all_d=[]
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""url TEXT, ""tv_movie TEXT);" % 'add_cat')
    
   
    dbcon.commit()
    dbcur.execute("SELECT * FROM add_cat")
    match = dbcur.fetchall()
    dbcur.close()
    dbcon.close()
    
    all_s_strings=[]
    for name,url,tv_movie in match:
        
        if (tv_movie=='movie'):
           aa=addDir3('[COLOR goldenrod][B]'+name+'[/B][/COLOR]',url,14,BASE_LOGO+'int.png',all_fanarts['32295'],'Tmdb_custom')
           all_d.append(aa)
    
    aa=addDir3('[COLOR goldenrod]Asgard 4K Movies Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/4k.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','4K Movies',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard 3D Movies Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/movie/3d.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','3D Movies',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard Movies Years Section[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/rd-movies.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Movies',search_db='')
    all_d.append(aa)  
    'Popular Movies'
    aa=addDir3(Addon.getLocalizedString(32036),'http://api.themoviedb.org/3/movie/popular?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&page=1'%lang,14,BASE_LOGO+'basic.png',all_fanarts['32036'],'Tmdb')
    all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32295),'http://api.themoviedb.org/3/movie/now_playing?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&page=1'%lang,14,BASE_LOGO+'basic.png',all_fanarts['32295'],'Tmdb')
    all_d.append(aa)
    #Genre
    aa=addDir3(Addon.getLocalizedString(32038),'http://api.themoviedb.org/3/genre/movie/list?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&page=1'%lang,18,BASE_LOGO+'basic.png',all_fanarts['32038'],'Tmdb')
    all_d.append(aa)
    #Years
    aa=addDir3(Addon.getLocalizedString(32039),'movie_years&page=1',14,BASE_LOGO+'basic.png',all_fanarts['32039'],'Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32040),'movie_years&page=1',112,BASE_LOGO+'basic.png',all_fanarts['32040'],'Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32041),'advance_movie',14,BASE_LOGO+'basic.png',all_fanarts['32041'],'Advance Content selection')
    all_d.append(aa)
    #Search movie
    aa=addDir3(Addon.getLocalizedString(32042),'http://api.themoviedb.org/3/search/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&query=%s&language={0}&append_to_response=origin_country&page=1'.format(lang),14,BASE_LOGO+'basic.png',all_fanarts['32042'],'Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32043),'movie',143,BASE_LOGO+'basic.png',all_fanarts['32043'],'TMDB')
    all_d.append(aa)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    
    table_name='lastlinkmovie'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    
    dbcur.execute("SELECT * FROM lastlinkmovie WHERE o_name='f_name'")

    match = dbcur.fetchone()
    dbcon.commit()
    
    dbcur.close()
    dbcon.close()
    
    if match!=None:
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
           
               url=base64.b64decode(url)
              
             aa=addLink('[I]%s[/I]'%Addon.getLocalizedString(32022), url,6,False,iconimage,fanart,description,data=show_original_year,prev_name=name,original_title=original_title,season=season,episode=episode,tmdb=id,year=show_original_year,place_control=True)
             all_d.append(aa)
       except  Exception as e:
         log.warning(e)
         pass
    aa=addDir3(Addon.getLocalizedString(32044),'movie',145,BASE_LOGO+'basic.png',all_fanarts['32044'],'History')
    
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32045),'0',174,BASE_LOGO+'basic.png',all_fanarts['32045'],'classic')
    
    all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32046),'0',176,BASE_LOGO+'basic.png',all_fanarts['32046'],'classic')
    
    all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32047),'0',178,BASE_LOGO+'basic.png',all_fanarts['32047'],'3D')
    
    all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32313),'0',187,BASE_LOGO+'basic.png',all_fanarts['32313'],'keywords')
    
    all_d.append(aa)
    #place your Jen playlist here:
    #dulpicate this line with your address
    #aa=addDir3('Name', 'Your Jen Address',189,'Iconimage','fanart','Description',search_db='Your Search db Address')
    #all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))

def movie_prodiction():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    
    
    aa=addDir3('[COLOR goldenrod]Marvel[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=7505&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Marvel')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]DC Studios[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=9993&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','DC Studios')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Lucasfilm[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=1&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Lucasfilm')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Warner Bros.[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=174&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','SyFy')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Walt Disney Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=2&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Walt Disney Pictures')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Pixar[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=3&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Pixar')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Paramount[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=4&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Paramount')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Columbia Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=5&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Columbia Pictures')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]DreamWorks[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=7&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','DreamWorks')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Miramax[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=14&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Miramax')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]20th Century Fox[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=25&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','20th Century Fox')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Sony Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=34&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Sony Pictures')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Lions Gate Films[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=35&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Lions Gate Films')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Orion Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=41&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Lions Gate Films')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]MGM[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=21&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','MGM')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]New Line Cinema[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=12&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','New Line Cinema')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Gracie Films[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=18&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Gracie Films')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Imagine Entertainment[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_companies=23&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Imagine Entertainment')
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def main_trakt():
   all_d=[]
   if Addon.getSetting('trakt_world')=='true':
        aa=addDir3(Addon.getLocalizedString(32026),'www',21,BASE_LOGO+'basic.png',all_fanarts['32026'],'No account needed)')
        all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32048),'movie?limit=40&page=1',116,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Lists')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32049),'tv?limit=40&page=1',116,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Lists')
   all_d.append(aa)
   import datetime
   current_date = adjusted_datetime()
   start = (current_date - datetime.timedelta(days=14)).strftime('%Y-%m-%d')
   finish = 14
        
   aa=addDir3(Addon.getLocalizedString(32050),'calendars/my/shows/%s/%s?limit=40&page=1'%(start,finish),117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Lists')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32051),'users/me/watched/shows?extended=full&limit=40&page=1',115,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Progress')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32052),'sync/watchlist/episodes?extended=full&limit=40&page=1',115,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Episodes')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32053),'users/me/watchlist/episodes?extended=full&limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Series')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32054),'users/me/collection/shows?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','TV')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32055),'users/me/watchlist/shows?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Shows')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32056),'recommendations/shows?limit=40&ignore_collected=true&page=1',166,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Movies')
   all_d.append(aa)
   
   aa=addDir3(Addon.getLocalizedString(32057),'users/me/watchlist/movies?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Movies')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32058),'recommendations/movies?limit=40&ignore_collected=true&page=1',166,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Movies')
   all_d.append(aa)
   
   aa=addDir3(Addon.getLocalizedString(32059),'users/me/watched/movies?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Watched')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32060),'users/me/watched/shows?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Watched shows')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32061),'users/me/collection/movies?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','collection')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32062),'users/likes/lists?limit=40&page=1',118,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Liked lists')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32063),'sync/playback/movies?limit=40&page=1',117,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Liked lists')
   all_d.append(aa)
   
   aa=addDir3(Addon.getLocalizedString(32064),'sync/playback/episodes?limit=40&page=1',164,BASE_LOGO+'basic.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Liked lists')
   all_d.append(aa)
   
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))

def tv_show_menu():
    all_d=[]
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""url TEXT, ""tv_movie TEXT);" % 'add_cat')
    
   
    dbcon.commit()
    dbcur.execute("SELECT * FROM add_cat")
    match = dbcur.fetchall()
    dbcur.close()
    dbcon.close()
    
    all_s_strings=[]
    for name,url,tv_movie in match:
        
        if (tv_movie=='tv'):
           aa=addDir3('[COLOR goldenrod][B]'+name+'[/B][/COLOR]',url,14,BASE_LOGO+'int.png',all_fanarts['32295'],'Tmdb_custom')
           all_d.append(aa)
    import datetime
    now = datetime.datetime.now()
    aa=addDir3('[COLOR goldenrod]Asgard New Releases[/COLOR]', 'https://mylostsoulspace.co.uk/fourk/NewReleases.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','New Releases',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard 4K TV Shows[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/4ktv.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','4K TV Shows',search_db='')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Asgard A-Z TV Shows[/COLOR]', 'https://mylostsoulspace.co.uk/Addon-1/Addon/text/rd/rd-tvcomplete.xml',189,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','TV Shows',search_db='')
    all_d.append(aa)
    import datetime
    now = datetime.datetime.now()
    aa=addDir3(Addon.getLocalizedString(32023),'tv',145,BASE_LOGO+'basic.png',all_fanarts['32023'],'History')
    #Popular
    aa=addDir3(Addon.getLocalizedString(32012),'http://api.themoviedb.org/3/tv/popular?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&page=1'%lang,14,BASE_LOGO+'basic.png',all_fanarts['32013'],'TMDB')
    all_d.append(aa)

    aa=addDir3(Addon.getLocalizedString(32013),'https://api.themoviedb.org/3/tv/on_the_air?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&page=1'%lang,14,BASE_LOGO+'basic.png',all_fanarts['32013'],'TMDB')
    all_d.append(aa)
    
    
    aa=addDir3(Addon.getLocalizedString(32014),'https://api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=en-US&sort_by=popularity.desc&first_air_date_year='+str(now.year)+'&timezone=America%2FNew_York&include_null_first_air_ates=false&language={0}&page=1'.format(lang),14,BASE_LOGO+'basic.png',all_fanarts['32014'],'New Tv shows')
    all_d.append(aa)
    #new episodes
    aa=addDir3(Addon.getLocalizedString(32015),'https://api.tvmaze.com/schedule',20,BASE_LOGO+'basic.png',all_fanarts['32015'],'New Episodes')
    all_d.append(aa)
    #Genre
    aa=addDir3(Addon.getLocalizedString(32016),'http://api.themoviedb.org/3/genre/tv/list?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&page=1'%lang,18,BASE_LOGO+'basic.png',all_fanarts['32016'],'TMDB')
    all_d.append(aa)
    #Years
    aa=addDir3(Addon.getLocalizedString(32017),'tv_years&page=1',14,BASE_LOGO+'basic.png',all_fanarts['32017'],'TMDB')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32018),'tv_years&page=1',101,BASE_LOGO+'basic.png',all_fanarts['32018'],'TMDB')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32019),'advance_tv',14,BASE_LOGO+'basic.png',all_fanarts['32019'],'Advance Content selection')
    
    all_d.append(aa)
    #Search tv
    aa=addDir3(Addon.getLocalizedString(32020),'http://api.themoviedb.org/3/search/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&query=%s&language={0}&page=1'.format(lang),14,BASE_LOGO+'basic.png',all_fanarts['32020'],'TMDB')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32021),'tv',143,BASE_LOGO+'basic.png',all_fanarts['32021'],'TMDB')
    all_d.append(aa)
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    
    table_name='lastlinktv'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    
    dbcur.execute("SELECT * FROM lastlinktv WHERE o_name='f_name'")

    match = dbcur.fetchone()
    dbcon.commit()
    
    dbcur.close()
    dbcon.close()
    
    if match!=None:
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
           
               url=base64.b64decode(url)
              
             aa=addLink('[I]%s[/I]'%Addon.getLocalizedString(32022), url,6,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,tmdb=id,year=show_original_year,place_control=True)
             all_d.append(aa)
       except  Exception as e:
         log.warning(e)
         pass
         
    
    
    
    aa=addDir3(Addon.getLocalizedString(32023),'tv',145,BASE_LOGO+'basic.png',all_fanarts['32023'],'History')
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def tv_neworks():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    aa=addDir3('[COLOR goldenrod]Disney+[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=2739&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Disney')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Apple TV+[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=2552&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','Apple')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]NetFlix[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=213&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','NetFlix')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]HBO[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=49&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','HBO')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]CBS[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=16&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','HBO')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]SyFy[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=77&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','SyFy')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]The CW[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=71&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','The CW')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]ABC[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=2&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','ABC')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]NBC[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=6&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','NBC')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]AMAZON[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=1024&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','AMAZON')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]hulu[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=453&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','hulu')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Showtime[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=67&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','showtime')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]BBC One[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=4&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','BBC')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]BBC Two[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=332&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','BBC')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]BBC Three[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=3&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','BBC')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]ITV[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&with_networks=9&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://mylostsoulspace.co.uk/images/asg/icon.png','https://mylostsoulspace.co.uk/images/asg/fanart.jpg','BBC')
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))