# -*- coding: utf-8 -*-
"""
TDLib Library Downloader
מוריד קבצי ספריות TDLib עבור telemedia (מבוסס data.json)
"""

import os
import sys
import time
import json
import platform
import logging
from urllib.request import Request, urlopen
from zipfile import ZipFile

try:
    import xbmcvfs
    import xbmcaddon
except ImportError:
    xbmcvfs = xbmcaddon = None

# Setup logging
logger = logging.getLogger(__name__)

# Constants – כתובת ה-JSON שלך
ADDON = xbmcaddon.Addon() if xbmcaddon else None
HOME = xbmcvfs.translatePath('special://home/') if xbmcvfs else os.path.expanduser('~')
ADDONS = os.path.join(HOME, 'addons')
TELEMEDIA_PATH = os.path.join(ADDONS, 'plugin.video.telemedia')
LIB_PATH = os.path.join(TELEMEDIA_PATH, 'resources', 'lib')
SERVER_LIB = 'https://silver.seedhost.eu/chiko/wizard/Tdlib/data.json'


def _translate_path(p):
    if xbmcvfs:
        return xbmcvfs.translatePath(p)
    return p.replace('special://home', ADDONS.replace('\\addons', '') or os.path.join(HOME, '.kodi'))


def _get_paths():
    """מחזיר LIB_PATH מתורגם אם צריך (לאדון ב-Kodi)."""
    if ADDON and xbmcvfs:
        addon_path = _translate_path(ADDON.getAddonInfo('path'))
        return os.path.join(addon_path, 'resources', 'lib')
    return LIB_PATH


def download_file(url, path):
    """
    מוריד קובץ מ-URL לנתיב מסוים. path = תיקיית היעד (נתיב מלא).
    """
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
    filename = url.split("/")[-1].split("?")[0]
    local_path = os.path.join(path, filename)
    if os.path.exists(local_path):
        logger.info("File already exists: %s", local_path)
        return local_path
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(req, timeout=60) as response, open(local_path, 'wb') as out_file:
            while True:
                chunk = response.read(8192)
                if not chunk:
                    break
                out_file.write(chunk)
        logger.info("Downloaded: %s", local_path)
        return local_path
    except Exception as e:
        logger.warning("Failed to download %s: %s", url, e)
        return None


def download_tdlib():
    """
    מוריד קבצי ספריות TDLib בהתאם לפלטפורמה (מקור: data.json)
    """
    base_lib = _get_paths()
    try:
        platform_info = platform.architecture()
        if sys.platform.lower().startswith('linux'):
            plat = 'linux'
            if 'ANDROID_DATA' in os.environ:
                plat = 'android'
        elif sys.platform.lower().startswith('win'):
            plat = 'windows'
        elif sys.platform.lower().startswith('darwin'):
            plat = 'darwin'
        else:
            plat = None
        if not plat:
            logger.warning("Unknown platform, skipping TDLib download")
            return False
        try:
            req = Request(SERVER_LIB, headers={"User-Agent": "Mozilla/5.0"})
            with urlopen(req, timeout=15) as resp:
                x = json.loads(resp.read().decode())
        except Exception as e:
            logger.error("Failed to load library info: %s", e)
            return False
        if plat == 'android':
            if platform_info[0] == '32bit':
                url = x.get('android32')
                cur = os.path.join(base_lib, "android", "armeabi-v7a")
            else:
                url = x.get('android64')
                cur = os.path.join(base_lib, "android", "arm64-v8a")
            if url:
                download_file(url, cur)
        elif plat == 'windows':
            if platform_info[0] == '64bit':
                cur = os.path.join(base_lib, 'windows', 'x64')
                url = x.get('windows64')
                if url:
                    file_windows = download_file(url, cur)
                    if file_windows and file_windows.endswith('.zip'):
                        with ZipFile(file_windows, 'r') as zf:
                            for file in zf.infolist():
                                zf.extract(member=file, path=cur)
                        time.sleep(1)
                        try:
                            os.remove(file_windows)
                        except OSError:
                            pass
            else:
                cur = os.path.join(base_lib, 'windows', 'x32')
                url = x.get('windows32')
                if url:
                    file_windows = download_file(url, cur)
                    if file_windows and file_windows.endswith('.zip'):
                        with ZipFile(file_windows, 'r') as zf:
                            for file in zf.infolist():
                                zf.extract(member=file, path=cur)
                        time.sleep(1)
                        try:
                            os.remove(file_windows)
                        except OSError:
                            pass
        elif plat == 'linux':
            if platform_info[0] == '32bit':
                url = x.get('linux32')
                cur = os.path.join(base_lib, "linux", "x32")
            else:
                url = x.get('linux64')
                cur = os.path.join(base_lib, "linux", "x64")
            if url:
                download_file(url, cur)
        elif plat == 'darwin':
            cur = os.path.join(base_lib, 'mac', 'mac-os')
            url = x.get('mac')
            if url:
                file_mac = download_file(url, cur)
                if file_mac and file_mac.endswith('.zip'):
                    with ZipFile(file_mac, 'r') as zf:
                        for file in zf.infolist():
                            zf.extract(member=file, path=cur)
                    time.sleep(1)
                    try:
                        os.remove(file_mac)
                    except OSError:
                        pass
        logger.info("TDLib download completed successfully")
        return True
    except Exception as e:
        logger.error("Error downloading TDLib: %s", e)
        return False


def check_and_download_tdlib():
    """
    בודק אם קבצי TDLib קיימים, ואם לא – מוריד אותם מ-data.json
    """
    try:
        base_lib = _get_paths()
        if os.path.exists(base_lib):
            has_files = False
            for _root, _dirs, files in os.walk(base_lib):
                if files:
                    has_files = True
                    break
            if has_files:
                logger.info("TDLib files already exist, skipping download")
                return True
        logger.info("TDLib files not found, starting download...")
        return download_tdlib()
    except Exception as e:
        logger.error("Error checking TDLib: %s", e)
        return False
