import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.thorrent/?site=cFav&function=setBookmark)", True)
